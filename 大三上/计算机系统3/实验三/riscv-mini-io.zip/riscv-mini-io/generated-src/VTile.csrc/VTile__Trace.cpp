// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_c.h"
#include "VTile__Syms.h"


//======================

void VTile::traceChg(VerilatedVcd* vcdp, void* userthis, uint32_t code) {
    // Callback from vcd->dump()
    VTile* t = (VTile*)userthis;
    VTile__Syms* __restrict vlSymsp = t->__VlSymsp;  // Setup global symbol table
    if (vlSymsp->getClearActivity()) {
        t->traceChgThis(vlSymsp, vcdp, code);
    }
}

//======================


void VTile::traceChgThis(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c = code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
        if (VL_UNLIKELY((1U & (vlTOPp->__Vm_traceActivity 
                               | (vlTOPp->__Vm_traceActivity 
                                  >> 1U))))) {
            vlTOPp->traceChgThis__2(vlSymsp, vcdp, code);
        }
        if (VL_UNLIKELY((1U & (vlTOPp->__Vm_traceActivity 
                               | (vlTOPp->__Vm_traceActivity 
                                  >> 2U))))) {
            vlTOPp->traceChgThis__3(vlSymsp, vcdp, code);
        }
        if (VL_UNLIKELY((2U & vlTOPp->__Vm_traceActivity))) {
            vlTOPp->traceChgThis__4(vlSymsp, vcdp, code);
        }
        vlTOPp->traceChgThis__5(vlSymsp, vcdp, code);
    }
    // Final
    vlTOPp->__Vm_traceActivity = 0U;
}

void VTile::traceChgThis__2(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c = code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
        vcdp->chgBit(c+1,((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__stall)))));
        vcdp->chgBus(c+9,((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__npc)),32);
        vcdp->chgBit(c+17,(vlTOPp->Tile__DOT__icache__DOT___T_262));
        vcdp->chgBus(c+25,(((3U == (3U & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                          >> 2U))) ? 
                            vlTOPp->Tile__DOT__icache__DOT__read[3U]
                             : ((2U == (3U & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                              >> 2U)))
                                 ? vlTOPp->Tile__DOT__icache__DOT__read[2U]
                                 : ((1U == (3U & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                                  >> 2U)))
                                     ? vlTOPp->Tile__DOT__icache__DOT__read[1U]
                                     : vlTOPp->Tile__DOT__icache__DOT__read[0U])))),32);
        vcdp->chgBit(c+33,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_571));
        vcdp->chgBit(c+41,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT___T_219));
        vcdp->chgBus(c+49,((IData)((VL_ULL(0x7ffffffff) 
                                    & ((QData)((IData)(
                                                       (vlTOPp->Tile__DOT__core__DOT__dpath__DOT___T_202 
                                                        >> 2U))) 
                                       << 2U)))),32);
        vcdp->chgBus(c+57,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT___T_220[0U]),32);
        vcdp->chgBus(c+65,((0xfU & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT___T_235))),4);
        vcdp->chgBit(c+73,(((0x10000000U == (0xf0000000U 
                                             & vlTOPp->Tile__DOT__mmio__DOT__selector__DOT__addr))
                             ? ((0x10000000U == (0xfffffff0U 
                                                 & vlTOPp->Tile__DOT__mmio__DOT__regMapper__DOT__addr))
                                 ? ((0U == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state)) 
                                    | ((1U == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state)) 
                                       | ((2U == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state)) 
                                          | ((3U == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state)) 
                                             & (IData)(vlTOPp->Tile__DOT__uart__DOT__rx__DOT__buf__024__DOT___T_33)))))
                                 : (0x10010000U == vlTOPp->Tile__DOT__mmio__DOT__regMapper__DOT__addr))
                             : (IData)(vlTOPp->Tile__DOT__dcache__DOT___T_262))));
        vcdp->chgBus(c+81,(vlTOPp->Tile__DOT__mmio__DOT__selector__DOT___T_97),32);
        vcdp->chgBit(c+89,(((0U != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                            & ((1U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))
                                ? ((~ (IData)(vlTOPp->Tile__DOT__icache__DOT__hit)) 
                                   & (IData)(vlTOPp->Tile__DOT__icache__DOT__is_dirty))
                                : ((2U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                   & ((~ (IData)(vlTOPp->Tile__DOT__icache__DOT___T_130)) 
                                      & (IData)(vlTOPp->Tile__DOT__icache__DOT__is_dirty)))))));
        vcdp->chgBus(c+97,((IData)((VL_ULL(0x7ffffffff) 
                                    & ((QData)((IData)(
                                                       ((vlTOPp->Tile__DOT__icache__DOT__metaMem_tag_rmeta_data 
                                                         << 8U) 
                                                        | (0xffU 
                                                           & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                                              >> 4U))))) 
                                       << 4U)))),32);
        vcdp->chgQuad(c+105,(((IData)(vlTOPp->Tile__DOT__icache__DOT__value_1)
                               ? (((QData)((IData)(
                                                   vlTOPp->Tile__DOT__icache__DOT__read[3U])) 
                                   << 0x20U) | (QData)((IData)(
                                                               vlTOPp->Tile__DOT__icache__DOT__read[2U])))
                               : (((QData)((IData)(
                                                   vlTOPp->Tile__DOT__icache__DOT__read[1U])) 
                                   << 0x20U) | (QData)((IData)(
                                                               vlTOPp->Tile__DOT__icache__DOT__read[0U]))))),64);
        vcdp->chgBit(c+121,(vlTOPp->Tile__DOT__icache__DOT___GEN_139));
        vcdp->chgBit(c+129,(vlTOPp->Tile__DOT__mmio__DOT__selector__DOT___T_87));
        vcdp->chgBit(c+137,(vlTOPp->Tile__DOT__dcache__DOT___T_262));
        vcdp->chgBus(c+145,(((3U == (3U & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                                           >> 2U)))
                              ? vlTOPp->Tile__DOT__dcache__DOT__read[3U]
                              : ((2U == (3U & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                                               >> 2U)))
                                  ? vlTOPp->Tile__DOT__dcache__DOT__read[2U]
                                  : ((1U == (3U & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                                                   >> 2U)))
                                      ? vlTOPp->Tile__DOT__dcache__DOT__read[1U]
                                      : vlTOPp->Tile__DOT__dcache__DOT__read[0U])))),32);
        vcdp->chgBit(c+153,(vlTOPp->Tile__DOT__dcache__DOT___GEN_138));
        vcdp->chgBus(c+161,((IData)((VL_ULL(0x7ffffffff) 
                                     & ((QData)((IData)(
                                                        ((vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_data 
                                                          << 8U) 
                                                         | (0xffU 
                                                            & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                                                               >> 4U))))) 
                                        << 4U)))),32);
        vcdp->chgBit(c+169,(vlTOPp->Tile__DOT__dcache__DOT___GEN_140));
        vcdp->chgQuad(c+177,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__value_1)
                               ? (((QData)((IData)(
                                                   vlTOPp->Tile__DOT__dcache__DOT__read[3U])) 
                                   << 0x20U) | (QData)((IData)(
                                                               vlTOPp->Tile__DOT__dcache__DOT__read[2U])))
                               : (((QData)((IData)(
                                                   vlTOPp->Tile__DOT__dcache__DOT__read[1U])) 
                                   << 0x20U) | (QData)((IData)(
                                                               vlTOPp->Tile__DOT__dcache__DOT__read[0U]))))),64);
        vcdp->chgBit(c+193,(vlTOPp->Tile__DOT__dcache__DOT___GEN_141));
        vcdp->chgBit(c+201,(vlTOPp->Tile__DOT__dcache__DOT___GEN_139));
        vcdp->chgBit(c+209,(vlTOPp->Tile__DOT__arb__DOT___T_221));
        vcdp->chgBit(c+217,(((IData)(vlTOPp->Tile__DOT__dcache__DOT___GEN_140) 
                             & (3U == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)))));
        vcdp->chgBit(c+225,(vlTOPp->Tile__DOT__arb__DOT___T_231));
        vcdp->chgBit(c+233,(((((IData)(vlTOPp->Tile__DOT__icache__DOT___GEN_139) 
                               | (IData)(vlTOPp->Tile__DOT__dcache__DOT___GEN_139)) 
                              & (~ (IData)(vlTOPp->Tile__DOT__arb__DOT___T_221))) 
                             & (0U == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)))));
        vcdp->chgBus(c+241,(((IData)(vlTOPp->Tile__DOT__dcache__DOT___GEN_139)
                              ? (IData)((VL_ULL(0x7ffffffff) 
                                         & ((QData)((IData)(
                                                            (0xfffffffU 
                                                             & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                                                                >> 4U)))) 
                                            << 4U)))
                              : (IData)((VL_ULL(0x7ffffffff) 
                                         & ((QData)((IData)(
                                                            (0xfffffffU 
                                                             & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                                                >> 4U)))) 
                                            << 4U))))),32);
        vcdp->chgBit(c+249,(vlTOPp->Tile__DOT__arb__DOT___T_271));
        vcdp->chgBit(c+257,(vlTOPp->Tile__DOT__mmio__DOT__regMapper__DOT___T_84));
        vcdp->chgBit(c+265,(((0U == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state)) 
                             | ((1U == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state)) 
                                | ((2U == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state)) 
                                   | ((3U == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state)) 
                                      & (IData)(vlTOPp->Tile__DOT__uart__DOT__rx__DOT__buf__024__DOT___T_33)))))));
        vcdp->chgBus(c+273,(vlTOPp->Tile__DOT__uartController__DOT___GEN_33),32);
        vcdp->chgBit(c+281,(vlTOPp->Tile__DOT__mmio__DOT__regMapper__DOT___T_89));
        vcdp->chgBit(c+289,(vlTOPp->Tile__DOT__uartController__DOT___GEN_34));
        vcdp->chgBit(c+297,(vlTOPp->Tile__DOT__uartController__DOT___GEN_36));
        vcdp->chgBus(c+305,(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT__ctrlSignals_0),2);
        vcdp->chgBit(c+313,(((0x37U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                             & ((0x17U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                & ((0x6fU == (0x7fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                   | ((0x67U == (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                      | ((0x63U != 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                         & ((0x1063U 
                                             != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                            & ((0x4063U 
                                                != 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                               & ((0x5063U 
                                                   != 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                                  & ((0x6063U 
                                                      != 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                                     & ((0x7063U 
                                                         != 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                                        & ((3U 
                                                            == 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                                           | ((0x1003U 
                                                               == 
                                                               (0x707fU 
                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                                              | (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___T_553)))))))))))))));
        vcdp->chgBit(c+321,(((0x37U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                             & ((0x17U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                & ((0x6fU != (0x7fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                   & ((0x67U == (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                      | ((0x63U != 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                         & ((0x1063U 
                                             != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                            & ((0x4063U 
                                                != 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                               & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___T_318))))))))));
        vcdp->chgBit(c+329,(((0x37U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                             & ((0x17U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___T_371)))));
        vcdp->chgBus(c+337,(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT__ctrlSignals_3),3);
        vcdp->chgBus(c+345,(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT__ctrlSignals_4),4);
        vcdp->chgBus(c+353,(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT__ctrlSignals_5),3);
        vcdp->chgBus(c+361,(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT__ctrlSignals_7),2);
        vcdp->chgBus(c+369,(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT__ctrlSignals_8),3);
        vcdp->chgBus(c+377,(((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst))
                              ? 0U : ((0x17U == (0x7fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst))
                                       ? 0U : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___T_707)))),2);
        vcdp->chgBit(c+385,(((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                             | ((0x17U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                | ((0x6fU == (0x7fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                   | ((0x67U == (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                      | ((0x63U != 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                         & ((0x1063U 
                                             != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                            & ((0x4063U 
                                                != 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                               & ((0x5063U 
                                                   != 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                                  & ((0x6063U 
                                                      != 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                                     & ((0x7063U 
                                                         != 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                                        & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___T_747)))))))))))));
        vcdp->chgBus(c+393,(((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst))
                              ? 0U : ((0x17U == (0x7fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst))
                                       ? 0U : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___T_803)))),3);
        vcdp->chgBit(c+401,(((0x37U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                             & ((0x17U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                & ((0x6fU != (0x7fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                   & ((0x67U != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                      & ((0x63U != 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                         & ((0x1063U 
                                             != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                            & ((0x4063U 
                                                != 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                               & ((0x5063U 
                                                   != 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                                  & ((0x6063U 
                                                      != 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                                     & ((0x7063U 
                                                         != 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                                        & ((3U 
                                                            != 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                                           & ((0x1003U 
                                                               != 
                                                               (0x707fU 
                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                                              & ((0x2003U 
                                                                  != 
                                                                  (0x707fU 
                                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)) 
                                                                 & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___T_840))))))))))))))));
        vcdp->chgBit(c+409,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__stall));
        vcdp->chgBus(c+417,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_295),32);
        vcdp->chgBus(c+425,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT___T_25),32);
        vcdp->chgBit(c+433,((((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_en) 
                              & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__stall))) 
                             & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_571)))));
        vcdp->chgBus(c+441,((IData)(((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel))
                                      ? (((QData)((IData)(
                                                          (1U 
                                                           & (IData)(
                                                                     (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__load 
                                                                      >> 0x20U))))) 
                                          << 0x21U) 
                                         | vlTOPp->Tile__DOT__core__DOT__dpath__DOT__load)
                                      : ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel))
                                          ? (VL_ULL(0x1ffffffff) 
                                             & (VL_ULL(4) 
                                                + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_pc))
                                          : (((QData)((IData)(
                                                              (1U 
                                                               & (IData)(
                                                                         (vlTOPp->Tile__DOT__core__DOT__dpath__DOT___T_284 
                                                                          >> 0x20U))))) 
                                              << 0x21U) 
                                             | vlTOPp->Tile__DOT__core__DOT__dpath__DOT___T_284))))),32);
        vcdp->chgBus(c+449,((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT___T_199)),32);
        vcdp->chgBus(c+457,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT___T_201),32);
        vcdp->chgBus(c+465,((((0U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT__ctrlSignals_4)) 
                              | (1U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT__ctrlSignals_4)))
                              ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_21)
                              : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_161)),32);
        vcdp->chgBus(c+473,((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_21)),32);
        vcdp->chgBus(c+481,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___T_53),32);
        vcdp->chgBus(c+489,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs1),32);
        vcdp->chgBus(c+497,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2),32);
        vcdp->chgBit(c+505,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT___T_41));
        vcdp->chgQuad(c+513,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__npc),33);
        vcdp->chgBus(c+529,(((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT___T_177)
                              ? 0x13U : ((3U == (3U 
                                                 & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                                    >> 2U)))
                                          ? vlTOPp->Tile__DOT__icache__DOT__read[3U]
                                          : ((2U == 
                                              (3U & 
                                               (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                                >> 2U)))
                                              ? vlTOPp->Tile__DOT__icache__DOT__read[2U]
                                              : ((1U 
                                                  == 
                                                  (3U 
                                                   & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                                      >> 2U)))
                                                  ? 
                                                 vlTOPp->Tile__DOT__icache__DOT__read[1U]
                                                  : 
                                                 vlTOPp->Tile__DOT__icache__DOT__read[0U]))))),32);
        vcdp->chgQuad(c+537,((VL_ULL(0x7ffffffff) & 
                              ((QData)((IData)((vlTOPp->Tile__DOT__core__DOT__dpath__DOT___T_202 
                                                >> 2U))) 
                               << 2U))),35);
        vcdp->chgBus(c+553,((0xffU & ((0x10U & ((IData)(
                                                        (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_21 
                                                         >> 1U)) 
                                                << 4U)) 
                                      | (8U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_21) 
                                               << 3U))))),8);
        vcdp->chgBus(c+561,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift),32);
        vcdp->chgQuad(c+569,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__load),33);
        vcdp->chgQuad(c+585,(((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel))
                               ? (((QData)((IData)(
                                                   (1U 
                                                    & (IData)(
                                                              (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__load 
                                                               >> 0x20U))))) 
                                   << 0x21U) | vlTOPp->Tile__DOT__core__DOT__dpath__DOT__load)
                               : ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel))
                                   ? (VL_ULL(0x1ffffffff) 
                                      & (VL_ULL(4) 
                                         + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_pc))
                                   : (((QData)((IData)(
                                                       (1U 
                                                        & (IData)(
                                                                  (vlTOPp->Tile__DOT__core__DOT__dpath__DOT___T_284 
                                                                   >> 0x20U))))) 
                                       << 0x21U) | vlTOPp->Tile__DOT__core__DOT__dpath__DOT___T_284)))),34);
        vcdp->chgBit(c+601,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__privValid));
        vcdp->chgBit(c+609,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEcall));
        vcdp->chgBit(c+617,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEbreak));
        vcdp->chgBit(c+625,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret));
        vcdp->chgBit(c+633,((((((((((((((((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_443) 
                                          | (0x301U 
                                             == (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                                    >> 0x14U)))) 
                                         | (0x302U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                                   >> 0x14U)))) 
                                        | (0x304U == 
                                           (0xfffU 
                                            & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                               >> 0x14U)))) 
                                       | (0x321U == 
                                          (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                            >> 0x14U)))) 
                                      | (0x701U == 
                                         (0xfffU & 
                                          (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                           >> 0x14U)))) 
                                     | (0x741U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                                      >> 0x14U)))) 
                                    | (0x340U == (0xfffU 
                                                  & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                                     >> 0x14U)))) 
                                   | (0x341U == (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                                    >> 0x14U)))) 
                                  | (0x342U == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                                   >> 0x14U)))) 
                                 | (0x343U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                                  >> 0x14U)))) 
                                | (0x344U == (0xfffU 
                                              & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                                 >> 0x14U)))) 
                               | (0x780U == (0xfffU 
                                             & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                                >> 0x14U)))) 
                              | (0x781U == (0xfffU 
                                            & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                               >> 0x14U)))) 
                             | (0x300U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                            >> 0x14U))))));
        vcdp->chgBit(c+641,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen));
        vcdp->chgBus(c+649,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata),32);
        vcdp->chgBit(c+657,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__iaddrInvalid));
        vcdp->chgBit(c+665,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__laddrInvalid));
        vcdp->chgBit(c+673,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__saddrInvalid));
        vcdp->chgBit(c+681,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isInstRet));
        vcdp->chgBit(c+689,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT___T_33));
        vcdp->chgBit(c+697,((1U & (((1U & (IData)((vlTOPp->Tile__DOT__core__DOT__dpath__DOT___T_199 
                                                   >> 0x1fU))) 
                                    == (1U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT___T_201 
                                              >> 0x1fU)))
                                    ? (IData)((vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_21 
                                               >> 0x1fU))
                                    : ((2U & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT__ctrlSignals_4))
                                        ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT___T_201 
                                           >> 0x1fU)
                                        : (IData)((vlTOPp->Tile__DOT__core__DOT__dpath__DOT___T_199 
                                                   >> 0x1fU)))))));
        vcdp->chgBus(c+705,((0x1fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT___T_201)),5);
        vcdp->chgBus(c+713,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT__shin),32);
        vcdp->chgBus(c+721,((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_87)),32);
        vcdp->chgBus(c+729,(((0x55555555U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_128 
                                             >> 1U)) 
                             | (0xaaaaaaaaU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_128 
                                               << 1U)))),32);
        vcdp->chgBus(c+737,((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT___T_13)),32);
        vcdp->chgBit(c+745,((0U != (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT___T_13))));
        vcdp->chgBit(c+753,((0U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT___T_13))));
        vcdp->chgBit(c+761,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__isSameSign));
        vcdp->chgBit(c+769,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__lt));
        vcdp->chgBit(c+777,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__ltu));
        vcdp->chgBit(c+785,((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__lt)))));
        vcdp->chgBit(c+793,((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__ltu)))));
        vcdp->chgBus(c+801,(vlTOPp->Tile__DOT__icache__DOT__metaMem_tag_rmeta_data),20);
        vcdp->chgBit(c+809,(vlTOPp->Tile__DOT__icache__DOT__hit));
        vcdp->chgBus(c+817,((0xffU & (IData)((vlTOPp->Tile__DOT__core__DOT__dpath__DOT__npc 
                                              >> 4U)))),8);
        vcdp->chgArray(c+825,(vlTOPp->Tile__DOT__icache__DOT__rdata),128);
        vcdp->chgArray(c+857,(vlTOPp->Tile__DOT__icache__DOT__read),128);
        vcdp->chgBit(c+889,(vlTOPp->Tile__DOT__icache__DOT__is_dirty));
        vcdp->chgBus(c+897,(vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_data),20);
        vcdp->chgBit(c+905,(vlTOPp->Tile__DOT__dcache__DOT__hit));
        vcdp->chgBus(c+913,((0xffU & (IData)((VL_ULL(0x7fffffff) 
                                              & ((QData)((IData)(
                                                                 (vlTOPp->Tile__DOT__core__DOT__dpath__DOT___T_202 
                                                                  >> 2U))) 
                                                 >> 2U))))),8);
        vcdp->chgArray(c+921,(vlTOPp->Tile__DOT__dcache__DOT__rdata),128);
        vcdp->chgArray(c+953,(vlTOPp->Tile__DOT__dcache__DOT__read),128);
        vcdp->chgBit(c+985,(vlTOPp->Tile__DOT__dcache__DOT__is_dirty));
        vcdp->chgBit(c+993,(vlTOPp->Tile__DOT__mmio__DOT__selector__DOT___T_92));
        vcdp->chgBit(c+1001,(((0x10000000U == (0xfffffff0U 
                                               & vlTOPp->Tile__DOT__mmio__DOT__regMapper__DOT__addr))
                               ? ((0U == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state)) 
                                  | ((1U == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state)) 
                                     | ((2U == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state)) 
                                        | ((3U == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state)) 
                                           & (IData)(vlTOPp->Tile__DOT__uart__DOT__rx__DOT__buf__024__DOT___T_33)))))
                               : (0x10010000U == vlTOPp->Tile__DOT__mmio__DOT__regMapper__DOT__addr))));
        vcdp->chgBus(c+1009,(((0x10000000U == (0xfffffff0U 
                                               & vlTOPp->Tile__DOT__mmio__DOT__regMapper__DOT__addr))
                               ? vlTOPp->Tile__DOT__uartController__DOT___GEN_33
                               : 0U)),32);
        vcdp->chgBus(c+1017,(vlTOPp->Tile__DOT__sender__DOT___GEN_3),8);
        vcdp->chgBit(c+1025,(vlTOPp->Tile__DOT__sender__DOT__tx__DOT__tx__DOT__baud_wrap_out));
        vcdp->chgBit(c+1033,(vlTOPp->Tile__DOT__sender__DOT__tx__DOT__tx__DOT__bit_wrap_out));
        vcdp->chgBit(c+1041,(vlTOPp->Tile__DOT__uart__DOT__tx__DOT__tx__DOT__baud_wrap_out));
        vcdp->chgBit(c+1049,(vlTOPp->Tile__DOT__uart__DOT__tx__DOT__tx__DOT__bit_wrap_out));
        vcdp->chgBit(c+1057,(vlTOPp->Tile__DOT__uart__DOT__rx__DOT__rx__DOT__first_wrap_out));
        vcdp->chgBit(c+1065,(vlTOPp->Tile__DOT__uart__DOT__rx__DOT__rx__DOT__baud_wrap_out));
        vcdp->chgBit(c+1073,(vlTOPp->Tile__DOT__uart__DOT__rx__DOT__rx__DOT__bit_wrap_out));
    }
}

void VTile::traceChgThis__3(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c = code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
        vcdp->chgBit(c+1081,(vlTOPp->Tile__DOT__arb__DOT___T_262));
        vcdp->chgBit(c+1089,(vlTOPp->Tile__DOT__arb__DOT___T_223));
        vcdp->chgBit(c+1097,(vlTOPp->Tile__DOT__arb__DOT___T_227));
        vcdp->chgBit(c+1105,(vlTOPp->Tile__DOT__dcache__DOT__write_wrap_out));
        vcdp->chgBit(c+1113,(vlTOPp->Tile__DOT__arb__DOT___T_259));
        vcdp->chgBit(c+1121,(vlTOPp->Tile__DOT__icache__DOT___GEN_58));
        vcdp->chgBus(c+1129,((0xffU & vlTOPp->Tile__DOT__icache__DOT__wdata[0U])),8);
        vcdp->chgBit(c+1137,(((IData)(vlTOPp->Tile__DOT__icache__DOT__wen) 
                              & vlTOPp->Tile__DOT__icache__DOT__wmask)));
        vcdp->chgBit(c+1145,(vlTOPp->Tile__DOT__icache__DOT__wen));
        vcdp->chgBus(c+1153,((0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[1U] 
                                        << 0x18U) | 
                                       (vlTOPp->Tile__DOT__icache__DOT__wdata[0U] 
                                        >> 8U)))),8);
        vcdp->chgBit(c+1161,(((IData)(vlTOPp->Tile__DOT__icache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                 >> 1U))));
        vcdp->chgBus(c+1169,((0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[1U] 
                                        << 0x10U) | 
                                       (vlTOPp->Tile__DOT__icache__DOT__wdata[0U] 
                                        >> 0x10U)))),8);
        vcdp->chgBit(c+1177,(((IData)(vlTOPp->Tile__DOT__icache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                 >> 2U))));
        vcdp->chgBus(c+1185,((0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[1U] 
                                        << 8U) | (vlTOPp->Tile__DOT__icache__DOT__wdata[0U] 
                                                  >> 0x18U)))),8);
        vcdp->chgBit(c+1193,(((IData)(vlTOPp->Tile__DOT__icache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                 >> 3U))));
        vcdp->chgBus(c+1201,((0xffU & vlTOPp->Tile__DOT__icache__DOT__wdata[1U])),8);
        vcdp->chgBit(c+1209,(((IData)(vlTOPp->Tile__DOT__icache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                 >> 4U))));
        vcdp->chgBus(c+1217,((0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[2U] 
                                        << 0x18U) | 
                                       (vlTOPp->Tile__DOT__icache__DOT__wdata[1U] 
                                        >> 8U)))),8);
        vcdp->chgBit(c+1225,(((IData)(vlTOPp->Tile__DOT__icache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                 >> 5U))));
        vcdp->chgBus(c+1233,((0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[2U] 
                                        << 0x10U) | 
                                       (vlTOPp->Tile__DOT__icache__DOT__wdata[1U] 
                                        >> 0x10U)))),8);
        vcdp->chgBit(c+1241,(((IData)(vlTOPp->Tile__DOT__icache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                 >> 6U))));
        vcdp->chgBus(c+1249,((0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[2U] 
                                        << 8U) | (vlTOPp->Tile__DOT__icache__DOT__wdata[1U] 
                                                  >> 0x18U)))),8);
        vcdp->chgBit(c+1257,(((IData)(vlTOPp->Tile__DOT__icache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                 >> 7U))));
        vcdp->chgBus(c+1265,((0xffU & vlTOPp->Tile__DOT__icache__DOT__wdata[2U])),8);
        vcdp->chgBit(c+1273,(((IData)(vlTOPp->Tile__DOT__icache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                 >> 8U))));
        vcdp->chgBus(c+1281,((0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[3U] 
                                        << 0x18U) | 
                                       (vlTOPp->Tile__DOT__icache__DOT__wdata[2U] 
                                        >> 8U)))),8);
        vcdp->chgBit(c+1289,(((IData)(vlTOPp->Tile__DOT__icache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                 >> 9U))));
        vcdp->chgBus(c+1297,((0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[3U] 
                                        << 0x10U) | 
                                       (vlTOPp->Tile__DOT__icache__DOT__wdata[2U] 
                                        >> 0x10U)))),8);
        vcdp->chgBit(c+1305,(((IData)(vlTOPp->Tile__DOT__icache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                 >> 0xaU))));
        vcdp->chgBus(c+1313,((0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[3U] 
                                        << 8U) | (vlTOPp->Tile__DOT__icache__DOT__wdata[2U] 
                                                  >> 0x18U)))),8);
        vcdp->chgBit(c+1321,(((IData)(vlTOPp->Tile__DOT__icache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                 >> 0xbU))));
        vcdp->chgBus(c+1329,((0xffU & vlTOPp->Tile__DOT__icache__DOT__wdata[3U])),8);
        vcdp->chgBit(c+1337,(((IData)(vlTOPp->Tile__DOT__icache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                 >> 0xcU))));
        vcdp->chgBus(c+1345,((0xffU & (vlTOPp->Tile__DOT__icache__DOT__wdata[3U] 
                                       >> 8U))),8);
        vcdp->chgBit(c+1353,(((IData)(vlTOPp->Tile__DOT__icache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                 >> 0xdU))));
        vcdp->chgBus(c+1361,((0xffU & (vlTOPp->Tile__DOT__icache__DOT__wdata[3U] 
                                       >> 0x10U))),8);
        vcdp->chgBit(c+1369,(((IData)(vlTOPp->Tile__DOT__icache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                 >> 0xeU))));
        vcdp->chgBus(c+1377,((0xffU & (vlTOPp->Tile__DOT__icache__DOT__wdata[3U] 
                                       >> 0x18U))),8);
        vcdp->chgBit(c+1385,(((IData)(vlTOPp->Tile__DOT__icache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                 >> 0xfU))));
        vcdp->chgBit(c+1393,(vlTOPp->Tile__DOT__icache__DOT__read_wrap_out));
        vcdp->chgBit(c+1401,(vlTOPp->Tile__DOT__icache__DOT__is_alloc));
        vcdp->chgBit(c+1409,(vlTOPp->Tile__DOT__icache__DOT__ren));
        vcdp->chgBus(c+1417,(vlTOPp->Tile__DOT__icache__DOT__wmask),20);
        vcdp->chgArray(c+1425,(vlTOPp->Tile__DOT__icache__DOT__wdata),128);
        vcdp->chgBit(c+1457,(vlTOPp->Tile__DOT__dcache__DOT___GEN_58));
        vcdp->chgBus(c+1465,((0xffU & vlTOPp->Tile__DOT__dcache__DOT__wdata[0U])),8);
        vcdp->chgBit(c+1473,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__wen) 
                              & vlTOPp->Tile__DOT__dcache__DOT__wmask)));
        vcdp->chgBit(c+1481,(vlTOPp->Tile__DOT__dcache__DOT__wen));
        vcdp->chgBus(c+1489,((0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] 
                                        << 0x18U) | 
                                       (vlTOPp->Tile__DOT__dcache__DOT__wdata[0U] 
                                        >> 8U)))),8);
        vcdp->chgBit(c+1497,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                 >> 1U))));
        vcdp->chgBus(c+1505,((0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] 
                                        << 0x10U) | 
                                       (vlTOPp->Tile__DOT__dcache__DOT__wdata[0U] 
                                        >> 0x10U)))),8);
        vcdp->chgBit(c+1513,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                 >> 2U))));
        vcdp->chgBus(c+1521,((0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] 
                                        << 8U) | (vlTOPp->Tile__DOT__dcache__DOT__wdata[0U] 
                                                  >> 0x18U)))),8);
        vcdp->chgBit(c+1529,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                 >> 3U))));
        vcdp->chgBus(c+1537,((0xffU & vlTOPp->Tile__DOT__dcache__DOT__wdata[1U])),8);
        vcdp->chgBit(c+1545,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                 >> 4U))));
        vcdp->chgBus(c+1553,((0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] 
                                        << 0x18U) | 
                                       (vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] 
                                        >> 8U)))),8);
        vcdp->chgBit(c+1561,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                 >> 5U))));
        vcdp->chgBus(c+1569,((0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] 
                                        << 0x10U) | 
                                       (vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] 
                                        >> 0x10U)))),8);
        vcdp->chgBit(c+1577,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                 >> 6U))));
        vcdp->chgBus(c+1585,((0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] 
                                        << 8U) | (vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] 
                                                  >> 0x18U)))),8);
        vcdp->chgBit(c+1593,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                 >> 7U))));
        vcdp->chgBus(c+1601,((0xffU & vlTOPp->Tile__DOT__dcache__DOT__wdata[2U])),8);
        vcdp->chgBit(c+1609,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                 >> 8U))));
        vcdp->chgBus(c+1617,((0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] 
                                        << 0x18U) | 
                                       (vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] 
                                        >> 8U)))),8);
        vcdp->chgBit(c+1625,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                 >> 9U))));
        vcdp->chgBus(c+1633,((0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] 
                                        << 0x10U) | 
                                       (vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] 
                                        >> 0x10U)))),8);
        vcdp->chgBit(c+1641,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                 >> 0xaU))));
        vcdp->chgBus(c+1649,((0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] 
                                        << 8U) | (vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] 
                                                  >> 0x18U)))),8);
        vcdp->chgBit(c+1657,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                 >> 0xbU))));
        vcdp->chgBus(c+1665,((0xffU & vlTOPp->Tile__DOT__dcache__DOT__wdata[3U])),8);
        vcdp->chgBit(c+1673,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                 >> 0xcU))));
        vcdp->chgBus(c+1681,((0xffU & (vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] 
                                       >> 8U))),8);
        vcdp->chgBit(c+1689,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                 >> 0xdU))));
        vcdp->chgBus(c+1697,((0xffU & (vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] 
                                       >> 0x10U))),8);
        vcdp->chgBit(c+1705,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                 >> 0xeU))));
        vcdp->chgBus(c+1713,((0xffU & (vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] 
                                       >> 0x18U))),8);
        vcdp->chgBit(c+1721,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__wen) 
                              & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                 >> 0xfU))));
        vcdp->chgBit(c+1729,(vlTOPp->Tile__DOT__dcache__DOT__read_wrap_out));
        vcdp->chgBit(c+1737,(vlTOPp->Tile__DOT__dcache__DOT__is_alloc));
        vcdp->chgBit(c+1745,(vlTOPp->Tile__DOT__dcache__DOT__ren));
        vcdp->chgBus(c+1753,(vlTOPp->Tile__DOT__dcache__DOT__wmask),20);
        vcdp->chgArray(c+1761,(vlTOPp->Tile__DOT__dcache__DOT__wdata),128);
    }
}

void VTile::traceChgThis__4(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c = code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
        vcdp->chgBus(c+1793,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost),32);
        vcdp->chgBit(c+1801,(((0U != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                              & ((1U != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                 & ((2U != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                    & (3U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)))))));
        vcdp->chgBit(c+1809,(((0U != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                              & ((1U != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                 & ((2U != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                    & ((3U != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                       & (4U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))))))));
        vcdp->chgBus(c+1817,((IData)((VL_ULL(0x7ffffffff) 
                                      & ((QData)((IData)(
                                                         (0xfffffffU 
                                                          & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                                             >> 4U)))) 
                                         << 4U)))),32);
        vcdp->chgBit(c+1825,((6U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))));
        vcdp->chgBus(c+1833,((IData)((VL_ULL(0x7ffffffff) 
                                      & ((QData)((IData)(
                                                         (0xfffffffU 
                                                          & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                                                             >> 4U)))) 
                                         << 4U)))),32);
        vcdp->chgBit(c+1841,((6U == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))));
        vcdp->chgBit(c+1849,((1U & (IData)(vlTOPp->Tile__DOT__sender__DOT__tx__DOT__tx__DOT__shiftReg))));
        vcdp->chgBit(c+1857,((1U & (IData)(vlTOPp->Tile__DOT__uart__DOT__tx__DOT__tx__DOT__shiftReg))));
        vcdp->chgBit(c+1865,(vlTOPp->Tile__DOT__uart__DOT__rx__DOT__buf__024__DOT__state));
        vcdp->chgBus(c+1873,(vlTOPp->Tile__DOT__uart__DOT__rx__DOT__buf__024__DOT__data),8);
        vcdp->chgBit(c+1881,((1U & (~ (IData)(vlTOPp->Tile__DOT__uart__DOT__tx__DOT__buf__024__DOT__state)))));
        vcdp->chgBus(c+1889,(((0U == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state))
                               ? 0U : ((1U == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state))
                                        ? 0U : ((2U 
                                                 == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state))
                                                 ? 0U
                                                 : 
                                                ((3U 
                                                  == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state))
                                                  ? 0U
                                                  : 
                                                 ((4U 
                                                   == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state))
                                                   ? 
                                                  (0xffU 
                                                   & vlTOPp->Tile__DOT__uartController__DOT__wdata)
                                                   : 0U)))))),8);
        vcdp->chgBus(c+1897,(vlTOPp->Tile__DOT__ledController__DOT__ledState),4);
        vcdp->chgBus(c+1905,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst),32);
        vcdp->chgBus(c+1913,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd),3);
        vcdp->chgBus(c+1921,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_in),32);
        vcdp->chgBus(c+1929,((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_pc)),32);
        vcdp->chgBus(c+1937,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_alu),32);
        vcdp->chgBus(c+1945,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst),32);
        vcdp->chgBit(c+1953,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__illegal));
        vcdp->chgBus(c+1961,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__st_type),2);
        vcdp->chgBus(c+1969,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type),3);
        vcdp->chgBit(c+1977,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__pc_check));
        vcdp->chgBus(c+1985,(((IData)(0x100U) + (IData)((QData)((IData)(
                                                                        (0xffU 
                                                                         & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV) 
                                                                            << 6U))))))),32);
        vcdp->chgBus(c+1993,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc),32);
        vcdp->chgBus(c+2001,((0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                       >> 0xfU))),5);
        vcdp->chgBus(c+2009,((0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                       >> 0x14U))),5);
        vcdp->chgBus(c+2017,(((0U != (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                               >> 0x14U)))
                               ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs
                              [(0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                         >> 0x14U))]
                               : 0U)),32);
        vcdp->chgBus(c+2025,((0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                       >> 7U))),5);
        vcdp->chgQuad(c+2033,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_pc),33);
        vcdp->chgQuad(c+2049,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_pc),33);
        vcdp->chgBus(c+2065,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel),2);
        vcdp->chgBit(c+2073,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_en));
        vcdp->chgBit(c+2081,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__started));
        vcdp->chgQuad(c+2089,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__pc),33);
        vcdp->chgBit(c+2105,((((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_en) 
                               & (0U != (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                                  >> 0xfU)))) 
                              & ((0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                           >> 0xfU)) 
                                 == (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                              >> 7U))))));
        vcdp->chgBit(c+2113,((((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_en) 
                               & (0U != (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                                  >> 0x14U)))) 
                              & ((0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                           >> 0x14U)) 
                                 == (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                              >> 7U))))));
        vcdp->chgBus(c+2121,((0xffU & ((0x10U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_alu 
                                                 << 3U)) 
                                       | (8U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_alu 
                                                << 3U))))),8);
        vcdp->chgBus(c+2129,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time__024),32);
        vcdp->chgBus(c+2137,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__timeh),32);
        vcdp->chgBus(c+2145,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle),32);
        vcdp->chgBus(c+2153,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycleh),32);
        vcdp->chgBus(c+2161,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instret),32);
        vcdp->chgBus(c+2169,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instreth),32);
        vcdp->chgBus(c+2177,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV),2);
        vcdp->chgBus(c+2185,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1),2);
        vcdp->chgBit(c+2193,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE));
        vcdp->chgBit(c+2201,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE1));
        vcdp->chgBit(c+2209,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIP));
        vcdp->chgBit(c+2217,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE));
        vcdp->chgBit(c+2225,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIP));
        vcdp->chgBit(c+2233,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE));
        vcdp->chgBus(c+2241,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp),32);
        vcdp->chgBus(c+2249,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch),32);
        vcdp->chgBus(c+2257,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause),32);
        vcdp->chgBus(c+2265,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr),32);
        vcdp->chgBus(c+2273,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mfromhost),32);
        vcdp->chgBus(c+2281,((0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                        >> 0x14U))),12);
        vcdp->chgBus(c+2289,((0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                       >> 0xfU))),5);
        vcdp->chgBus(c+2297,((((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1) 
                               << 4U) | (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE1) 
                                          << 3U) | 
                                         (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV) 
                                           << 1U) | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE))))),32);
        vcdp->chgBus(c+2305,((((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIP) 
                               << 7U) | ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIP) 
                                         << 3U))),32);
        vcdp->chgBus(c+2313,((((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE) 
                               << 7U) | ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE) 
                                         << 3U))),32);
        vcdp->chgBit(c+2321,((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd))));
        vcdp->chgBit(c+2329,((((0U == (3U & (~ (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                                >> 0x1eU)))) 
                               | (0x301U == (0xfffU 
                                             & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                                >> 0x14U)))) 
                              | (0x302U == (0xfffU 
                                            & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_inst 
                                               >> 0x14U))))));
        vcdp->chgBus(c+2337,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[0]),32);
        vcdp->chgBus(c+2338,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[1]),32);
        vcdp->chgBus(c+2339,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[2]),32);
        vcdp->chgBus(c+2340,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[3]),32);
        vcdp->chgBus(c+2341,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[4]),32);
        vcdp->chgBus(c+2342,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[5]),32);
        vcdp->chgBus(c+2343,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[6]),32);
        vcdp->chgBus(c+2344,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[7]),32);
        vcdp->chgBus(c+2345,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[8]),32);
        vcdp->chgBus(c+2346,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[9]),32);
        vcdp->chgBus(c+2347,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[10]),32);
        vcdp->chgBus(c+2348,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[11]),32);
        vcdp->chgBus(c+2349,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[12]),32);
        vcdp->chgBus(c+2350,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[13]),32);
        vcdp->chgBus(c+2351,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[14]),32);
        vcdp->chgBus(c+2352,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[15]),32);
        vcdp->chgBus(c+2353,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[16]),32);
        vcdp->chgBus(c+2354,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[17]),32);
        vcdp->chgBus(c+2355,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[18]),32);
        vcdp->chgBus(c+2356,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[19]),32);
        vcdp->chgBus(c+2357,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[20]),32);
        vcdp->chgBus(c+2358,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[21]),32);
        vcdp->chgBus(c+2359,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[22]),32);
        vcdp->chgBus(c+2360,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[23]),32);
        vcdp->chgBus(c+2361,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[24]),32);
        vcdp->chgBus(c+2362,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[25]),32);
        vcdp->chgBus(c+2363,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[26]),32);
        vcdp->chgBus(c+2364,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[27]),32);
        vcdp->chgBus(c+2365,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[28]),32);
        vcdp->chgBus(c+2366,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[29]),32);
        vcdp->chgBus(c+2367,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[30]),32);
        vcdp->chgBus(c+2368,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[31]),32);
        vcdp->chgBus(c+2593,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs
                             [(0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                        >> 0xfU))]),32);
        vcdp->chgBus(c+2601,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs
                             [(0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                        >> 0x14U))]),32);
        vcdp->chgBus(c+2609,((0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                        >> 0x14U))),12);
        vcdp->chgBus(c+2617,(((0xfe0U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                         >> 0x14U)) 
                              | (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                          >> 7U)))),12);
        vcdp->chgBus(c+2625,((((0x1000U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                           >> 0x13U)) 
                               | ((0x800U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                             << 4U)) 
                                  | (0x7e0U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                               >> 0x14U)))) 
                              | (0x1eU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                          >> 7U)))),13);
        vcdp->chgBus(c+2633,((0xfffff000U & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst)),32);
        vcdp->chgBus(c+2641,((((0x100000U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                             >> 0xbU)) 
                               | ((0xff000U & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst) 
                                  | (0x800U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                               >> 9U)))) 
                              | (0x7feU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                           >> 0x14U)))),21);
        vcdp->chgBus(c+2649,((0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_inst 
                                       >> 0xfU))),6);
        vcdp->chgBus(c+2657,(vlTOPp->Tile__DOT__icache__DOT__state),3);
        vcdp->chgArray(c+2665,(vlTOPp->Tile__DOT__icache__DOT__v),256);
        vcdp->chgArray(c+2729,(vlTOPp->Tile__DOT__icache__DOT__d),256);
        vcdp->chgBus(c+2793,(vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3___05FT_170_addr_pipe_0),8);
        vcdp->chgBus(c+2801,((0xfffffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                          >> 0xcU))),20);
        vcdp->chgBus(c+2809,((0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                       >> 4U))),8);
        vcdp->chgBus(c+2817,(vlTOPp->Tile__DOT__icache__DOT__dataMem_0_0
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3___05FT_170_addr_pipe_0]),8);
        vcdp->chgBus(c+2825,(vlTOPp->Tile__DOT__icache__DOT__dataMem_0_1
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3___05FT_170_addr_pipe_0]),8);
        vcdp->chgBus(c+2833,(vlTOPp->Tile__DOT__icache__DOT__dataMem_0_2
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3___05FT_170_addr_pipe_0]),8);
        vcdp->chgBus(c+2841,(vlTOPp->Tile__DOT__icache__DOT__dataMem_0_3
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3___05FT_170_addr_pipe_0]),8);
        vcdp->chgBus(c+2849,(vlTOPp->Tile__DOT__icache__DOT__dataMem_1_0
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3___05FT_170_addr_pipe_0]),8);
        vcdp->chgBus(c+2857,(vlTOPp->Tile__DOT__icache__DOT__dataMem_1_1
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3___05FT_170_addr_pipe_0]),8);
        vcdp->chgBus(c+2865,(vlTOPp->Tile__DOT__icache__DOT__dataMem_1_2
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3___05FT_170_addr_pipe_0]),8);
        vcdp->chgBus(c+2873,(vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3___05FT_170_addr_pipe_0]),8);
        vcdp->chgBus(c+2881,(vlTOPp->Tile__DOT__icache__DOT__dataMem_2_0
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3___05FT_170_addr_pipe_0]),8);
        vcdp->chgBus(c+2889,(vlTOPp->Tile__DOT__icache__DOT__dataMem_2_1
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3___05FT_170_addr_pipe_0]),8);
        vcdp->chgBus(c+2897,(vlTOPp->Tile__DOT__icache__DOT__dataMem_2_2
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3___05FT_170_addr_pipe_0]),8);
        vcdp->chgBus(c+2905,(vlTOPp->Tile__DOT__icache__DOT__dataMem_2_3
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3___05FT_170_addr_pipe_0]),8);
        vcdp->chgBus(c+2913,(vlTOPp->Tile__DOT__icache__DOT__dataMem_3_0
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3___05FT_170_addr_pipe_0]),8);
        vcdp->chgBus(c+2921,(vlTOPp->Tile__DOT__icache__DOT__dataMem_3_1
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3___05FT_170_addr_pipe_0]),8);
        vcdp->chgBus(c+2929,(vlTOPp->Tile__DOT__icache__DOT__dataMem_3_2
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3___05FT_170_addr_pipe_0]),8);
        vcdp->chgBus(c+2937,(vlTOPp->Tile__DOT__icache__DOT__dataMem_3_3
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3___05FT_170_addr_pipe_0]),8);
        vcdp->chgBus(c+2945,(vlTOPp->Tile__DOT__icache__DOT__addr_reg),32);
        vcdp->chgBus(c+2953,(vlTOPp->Tile__DOT__icache__DOT__cpu_data),32);
        vcdp->chgBus(c+2961,(vlTOPp->Tile__DOT__icache__DOT__cpu_mask),4);
        vcdp->chgBit(c+2969,(vlTOPp->Tile__DOT__icache__DOT__value));
        vcdp->chgBit(c+2977,(vlTOPp->Tile__DOT__icache__DOT__value_1));
        vcdp->chgBit(c+2985,(vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg));
        vcdp->chgBit(c+2993,(vlTOPp->Tile__DOT__icache__DOT__ren_reg));
        vcdp->chgArray(c+3001,(vlTOPp->Tile__DOT__icache__DOT__rdata_buf),128);
        vcdp->chgQuad(c+3033,(vlTOPp->Tile__DOT__icache__DOT__refill_buf_0),64);
        vcdp->chgQuad(c+3049,(vlTOPp->Tile__DOT__icache__DOT__refill_buf_1),64);
        vcdp->chgBit(c+3065,((0U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))));
        vcdp->chgBit(c+3073,((1U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))));
        vcdp->chgBit(c+3081,((2U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))));
        vcdp->chgBus(c+3089,((3U & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                    >> 2U))),2);
        vcdp->chgBus(c+3097,(vlTOPp->Tile__DOT__dcache__DOT__state),3);
        vcdp->chgArray(c+3105,(vlTOPp->Tile__DOT__dcache__DOT__v),256);
        vcdp->chgArray(c+3169,(vlTOPp->Tile__DOT__dcache__DOT__d),256);
        vcdp->chgBus(c+3233,(vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0),8);
        vcdp->chgBus(c+3241,((0xfffffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                                          >> 0xcU))),20);
        vcdp->chgBus(c+3249,((0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                                       >> 4U))),8);
        vcdp->chgBus(c+3257,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_0
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBus(c+3265,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_1
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBus(c+3273,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_2
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBus(c+3281,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_3
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBus(c+3289,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_0
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBus(c+3297,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_1
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBus(c+3305,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_2
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBus(c+3313,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_3
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBus(c+3321,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_0
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBus(c+3329,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_1
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBus(c+3337,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_2
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBus(c+3345,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_3
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBus(c+3353,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_0
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBus(c+3361,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_1
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBus(c+3369,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_2
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBus(c+3377,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_3
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBus(c+3385,(vlTOPp->Tile__DOT__dcache__DOT__addr_reg),32);
        vcdp->chgBus(c+3393,(vlTOPp->Tile__DOT__dcache__DOT__cpu_data),32);
        vcdp->chgBus(c+3401,(vlTOPp->Tile__DOT__dcache__DOT__cpu_mask),4);
        vcdp->chgBit(c+3409,(vlTOPp->Tile__DOT__dcache__DOT__value));
        vcdp->chgBit(c+3417,(vlTOPp->Tile__DOT__dcache__DOT__value_1));
        vcdp->chgBit(c+3425,(vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg));
        vcdp->chgBit(c+3433,(vlTOPp->Tile__DOT__dcache__DOT__ren_reg));
        vcdp->chgArray(c+3441,(vlTOPp->Tile__DOT__dcache__DOT__rdata_buf),128);
        vcdp->chgQuad(c+3473,(vlTOPp->Tile__DOT__dcache__DOT__refill_buf_0),64);
        vcdp->chgQuad(c+3489,(vlTOPp->Tile__DOT__dcache__DOT__refill_buf_1),64);
        vcdp->chgBit(c+3505,((0U == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))));
        vcdp->chgBit(c+3513,((1U == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))));
        vcdp->chgBit(c+3521,((2U == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))));
        vcdp->chgBus(c+3529,((3U & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                                    >> 2U))),2);
        vcdp->chgBus(c+3537,(vlTOPp->Tile__DOT__arb__DOT__state),3);
        vcdp->chgBus(c+3545,(vlTOPp->Tile__DOT__mmio__DOT__selector__DOT__addr),32);
        vcdp->chgBus(c+3553,(vlTOPp->Tile__DOT__mmio__DOT__regMapper__DOT__addr),32);
        vcdp->chgBit(c+3561,((1U & (~ (IData)(vlTOPp->Tile__DOT__sender__DOT__tx__DOT__buf__024__DOT__state)))));
        vcdp->chgBit(c+3569,((4U != (IData)(vlTOPp->Tile__DOT__sender__DOT__cntReg))));
        vcdp->chgBus(c+3577,(vlTOPp->Tile__DOT__sender__DOT__cntReg),8);
        vcdp->chgBit(c+3585,((1U & (~ (IData)(vlTOPp->Tile__DOT__sender__DOT__tx__DOT__tx__DOT__state)))));
        vcdp->chgBit(c+3593,(vlTOPp->Tile__DOT__sender__DOT__tx__DOT__buf__024__DOT__state));
        vcdp->chgBus(c+3601,(vlTOPp->Tile__DOT__sender__DOT__tx__DOT__buf__024__DOT__data),8);
        vcdp->chgBit(c+3609,(vlTOPp->Tile__DOT__sender__DOT__tx__DOT__tx__DOT__state));
        vcdp->chgBus(c+3617,(vlTOPp->Tile__DOT__sender__DOT__tx__DOT__tx__DOT__shiftReg),11);
        vcdp->chgBus(c+3625,(vlTOPp->Tile__DOT__sender__DOT__tx__DOT__tx__DOT__value),11);
        vcdp->chgBus(c+3633,(vlTOPp->Tile__DOT__sender__DOT__tx__DOT__tx__DOT__value_1),4);
        vcdp->chgBit(c+3641,((1U & (~ (IData)(vlTOPp->Tile__DOT__uart__DOT__tx__DOT__tx__DOT__state)))));
        vcdp->chgBit(c+3649,(vlTOPp->Tile__DOT__uart__DOT__tx__DOT__buf__024__DOT__state));
        vcdp->chgBus(c+3657,(vlTOPp->Tile__DOT__uart__DOT__tx__DOT__buf__024__DOT__data),8);
        vcdp->chgBit(c+3665,(vlTOPp->Tile__DOT__uart__DOT__tx__DOT__tx__DOT__state));
        vcdp->chgBus(c+3673,(vlTOPp->Tile__DOT__uart__DOT__tx__DOT__tx__DOT__shiftReg),11);
        vcdp->chgBus(c+3681,(vlTOPp->Tile__DOT__uart__DOT__tx__DOT__tx__DOT__value),11);
        vcdp->chgBus(c+3689,(vlTOPp->Tile__DOT__uart__DOT__tx__DOT__tx__DOT__value_1),4);
        vcdp->chgBit(c+3697,(vlTOPp->Tile__DOT__uart__DOT__rx__DOT__rx__DOT___T_50));
        vcdp->chgBus(c+3705,(vlTOPp->Tile__DOT__uart__DOT__rx__DOT__rx__DOT__shiftReg),8);
        vcdp->chgBit(c+3713,((1U & (~ (IData)(vlTOPp->Tile__DOT__uart__DOT__rx__DOT__buf__024__DOT__state)))));
        vcdp->chgBus(c+3721,(vlTOPp->Tile__DOT__uart__DOT__rx__DOT__rx__DOT__state),2);
        vcdp->chgBus(c+3729,(vlTOPp->Tile__DOT__uart__DOT__rx__DOT__rx__DOT__value),12);
        vcdp->chgBus(c+3737,(vlTOPp->Tile__DOT__uart__DOT__rx__DOT__rx__DOT__value_1),11);
        vcdp->chgBus(c+3745,(vlTOPp->Tile__DOT__uart__DOT__rx__DOT__rx__DOT__value_2),3);
        vcdp->chgBus(c+3753,(vlTOPp->Tile__DOT__uartController__DOT__state),3);
        vcdp->chgBus(c+3761,(vlTOPp->Tile__DOT__uartController__DOT__rdata),32);
        vcdp->chgBus(c+3769,(vlTOPp->Tile__DOT__uartController__DOT__wdata),32);
        vcdp->chgBit(c+3777,((1U == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state))));
        vcdp->chgBit(c+3785,((2U == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state))));
        vcdp->chgBit(c+3793,((3U == (IData)(vlTOPp->Tile__DOT__uartController__DOT__state))));
    }
}

void VTile::traceChgThis__5(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c = code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
        vcdp->chgBit(c+3801,(vlTOPp->clock));
        vcdp->chgBit(c+3809,(vlTOPp->reset));
        vcdp->chgBit(c+3817,(vlTOPp->io_host_fromhost_valid));
        vcdp->chgBus(c+3825,(vlTOPp->io_host_fromhost_bits),32);
        vcdp->chgBus(c+3833,(vlTOPp->io_host_tohost),32);
        vcdp->chgBit(c+3841,(vlTOPp->io_nasti_aw_ready));
        vcdp->chgBit(c+3849,(vlTOPp->io_nasti_aw_valid));
        vcdp->chgBus(c+3857,(vlTOPp->io_nasti_aw_bits_addr),32);
        vcdp->chgBus(c+3865,(vlTOPp->io_nasti_aw_bits_len),8);
        vcdp->chgBus(c+3873,(vlTOPp->io_nasti_aw_bits_size),3);
        vcdp->chgBus(c+3881,(vlTOPp->io_nasti_aw_bits_burst),2);
        vcdp->chgBit(c+3889,(vlTOPp->io_nasti_aw_bits_lock));
        vcdp->chgBus(c+3897,(vlTOPp->io_nasti_aw_bits_cache),4);
        vcdp->chgBus(c+3905,(vlTOPp->io_nasti_aw_bits_prot),3);
        vcdp->chgBus(c+3913,(vlTOPp->io_nasti_aw_bits_qos),4);
        vcdp->chgBus(c+3921,(vlTOPp->io_nasti_aw_bits_region),4);
        vcdp->chgBus(c+3929,(vlTOPp->io_nasti_aw_bits_id),5);
        vcdp->chgBit(c+3937,(vlTOPp->io_nasti_aw_bits_user));
        vcdp->chgBit(c+3945,(vlTOPp->io_nasti_w_ready));
        vcdp->chgBit(c+3953,(vlTOPp->io_nasti_w_valid));
        vcdp->chgQuad(c+3961,(vlTOPp->io_nasti_w_bits_data),64);
        vcdp->chgBit(c+3977,(vlTOPp->io_nasti_w_bits_last));
        vcdp->chgBus(c+3985,(vlTOPp->io_nasti_w_bits_id),5);
        vcdp->chgBus(c+3993,(vlTOPp->io_nasti_w_bits_strb),8);
        vcdp->chgBit(c+4001,(vlTOPp->io_nasti_w_bits_user));
        vcdp->chgBit(c+4009,(vlTOPp->io_nasti_b_ready));
        vcdp->chgBit(c+4017,(vlTOPp->io_nasti_b_valid));
        vcdp->chgBus(c+4025,(vlTOPp->io_nasti_b_bits_resp),2);
        vcdp->chgBus(c+4033,(vlTOPp->io_nasti_b_bits_id),5);
        vcdp->chgBit(c+4041,(vlTOPp->io_nasti_b_bits_user));
        vcdp->chgBit(c+4049,(vlTOPp->io_nasti_ar_ready));
        vcdp->chgBit(c+4057,(vlTOPp->io_nasti_ar_valid));
        vcdp->chgBus(c+4065,(vlTOPp->io_nasti_ar_bits_addr),32);
        vcdp->chgBus(c+4073,(vlTOPp->io_nasti_ar_bits_len),8);
        vcdp->chgBus(c+4081,(vlTOPp->io_nasti_ar_bits_size),3);
        vcdp->chgBus(c+4089,(vlTOPp->io_nasti_ar_bits_burst),2);
        vcdp->chgBit(c+4097,(vlTOPp->io_nasti_ar_bits_lock));
        vcdp->chgBus(c+4105,(vlTOPp->io_nasti_ar_bits_cache),4);
        vcdp->chgBus(c+4113,(vlTOPp->io_nasti_ar_bits_prot),3);
        vcdp->chgBus(c+4121,(vlTOPp->io_nasti_ar_bits_qos),4);
        vcdp->chgBus(c+4129,(vlTOPp->io_nasti_ar_bits_region),4);
        vcdp->chgBus(c+4137,(vlTOPp->io_nasti_ar_bits_id),5);
        vcdp->chgBit(c+4145,(vlTOPp->io_nasti_ar_bits_user));
        vcdp->chgBit(c+4153,(vlTOPp->io_nasti_r_ready));
        vcdp->chgBit(c+4161,(vlTOPp->io_nasti_r_valid));
        vcdp->chgBus(c+4169,(vlTOPp->io_nasti_r_bits_resp),2);
        vcdp->chgQuad(c+4177,(vlTOPp->io_nasti_r_bits_data),64);
        vcdp->chgBit(c+4193,(vlTOPp->io_nasti_r_bits_last));
        vcdp->chgBus(c+4201,(vlTOPp->io_nasti_r_bits_id),5);
        vcdp->chgBit(c+4209,(vlTOPp->io_nasti_r_bits_user));
        vcdp->chgBit(c+4217,(vlTOPp->io_txd));
        vcdp->chgBit(c+4225,(vlTOPp->io_rxd));
        vcdp->chgBus(c+4233,(vlTOPp->io_ledState),4);
        vcdp->chgBit(c+4241,(((IData)(vlTOPp->io_nasti_r_valid) 
                              & (1U == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)))));
        vcdp->chgBit(c+4249,(((IData)(vlTOPp->io_nasti_b_valid) 
                              & (4U == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)))));
        vcdp->chgBit(c+4257,(((IData)(vlTOPp->io_nasti_r_valid) 
                              & (2U == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)))));
    }
}
