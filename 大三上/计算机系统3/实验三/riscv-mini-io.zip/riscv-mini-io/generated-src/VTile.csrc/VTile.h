// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Primary design header
//
// This header should be included by all source files instantiating the design.
// The class here is then constructed to instantiate the design.
// See the Verilator manual for examples.

#ifndef _VTILE_H_
#define _VTILE_H_  // guard

#include "verilated_heavy.h"

//==========

class VTile__Syms;
class VTile_VerilatedVcd;


//----------

VL_MODULE(VTile) {
  public:
    
    // PORTS
    // The application code writes and reads these signals to
    // propagate new values into/out from the Verilated model.
    VL_IN8(clock,0,0);
    VL_IN8(reset,0,0);
    VL_IN8(io_host_fromhost_valid,0,0);
    VL_IN8(io_nasti_aw_ready,0,0);
    VL_OUT8(io_nasti_aw_valid,0,0);
    VL_OUT8(io_nasti_aw_bits_len,7,0);
    VL_OUT8(io_nasti_aw_bits_size,2,0);
    VL_OUT8(io_nasti_aw_bits_burst,1,0);
    VL_OUT8(io_nasti_aw_bits_lock,0,0);
    VL_OUT8(io_nasti_aw_bits_cache,3,0);
    VL_OUT8(io_nasti_aw_bits_prot,2,0);
    VL_OUT8(io_nasti_aw_bits_qos,3,0);
    VL_OUT8(io_nasti_aw_bits_region,3,0);
    VL_OUT8(io_nasti_aw_bits_id,4,0);
    VL_OUT8(io_nasti_aw_bits_user,0,0);
    VL_IN8(io_nasti_w_ready,0,0);
    VL_OUT8(io_nasti_w_valid,0,0);
    VL_OUT8(io_nasti_w_bits_last,0,0);
    VL_OUT8(io_nasti_w_bits_id,4,0);
    VL_OUT8(io_nasti_w_bits_strb,7,0);
    VL_OUT8(io_nasti_w_bits_user,0,0);
    VL_OUT8(io_nasti_b_ready,0,0);
    VL_IN8(io_nasti_b_valid,0,0);
    VL_IN8(io_nasti_b_bits_resp,1,0);
    VL_IN8(io_nasti_b_bits_id,4,0);
    VL_IN8(io_nasti_b_bits_user,0,0);
    VL_IN8(io_nasti_ar_ready,0,0);
    VL_OUT8(io_nasti_ar_valid,0,0);
    VL_OUT8(io_nasti_ar_bits_len,7,0);
    VL_OUT8(io_nasti_ar_bits_size,2,0);
    VL_OUT8(io_nasti_ar_bits_burst,1,0);
    VL_OUT8(io_nasti_ar_bits_lock,0,0);
    VL_OUT8(io_nasti_ar_bits_cache,3,0);
    VL_OUT8(io_nasti_ar_bits_prot,2,0);
    VL_OUT8(io_nasti_ar_bits_qos,3,0);
    VL_OUT8(io_nasti_ar_bits_region,3,0);
    VL_OUT8(io_nasti_ar_bits_id,4,0);
    VL_OUT8(io_nasti_ar_bits_user,0,0);
    VL_OUT8(io_nasti_r_ready,0,0);
    VL_IN8(io_nasti_r_valid,0,0);
    VL_IN8(io_nasti_r_bits_resp,1,0);
    VL_IN8(io_nasti_r_bits_last,0,0);
    VL_IN8(io_nasti_r_bits_id,4,0);
    VL_IN8(io_nasti_r_bits_user,0,0);
    VL_OUT8(io_txd,0,0);
    VL_IN8(io_rxd,0,0);
    VL_OUT8(io_ledState,3,0);
    VL_IN(io_host_fromhost_bits,31,0);
    VL_OUT(io_host_tohost,31,0);
    VL_OUT(io_nasti_aw_bits_addr,31,0);
    VL_OUT(io_nasti_ar_bits_addr,31,0);
    VL_OUT64(io_nasti_w_bits_data,63,0);
    VL_IN64(io_nasti_r_bits_data,63,0);
    
    // LOCAL SIGNALS
    // Internals; generally not touched by application code
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        CData/*1:0*/ Tile__DOT__core__DOT__dpath__DOT__st_type;
        CData/*2:0*/ Tile__DOT__core__DOT__dpath__DOT__ld_type;
        CData/*1:0*/ Tile__DOT__core__DOT__dpath__DOT__wb_sel;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__wb_en;
        CData/*2:0*/ Tile__DOT__core__DOT__dpath__DOT__csr_cmd;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__illegal;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__pc_check;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__started;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__stall;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT___T_162;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT___T_177;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT___T_195;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT___T_219;
        CData/*1:0*/ Tile__DOT__core__DOT__dpath__DOT___T_221;
        CData/*4:0*/ Tile__DOT__core__DOT__dpath__DOT___T_235;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT___T_240;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT___T_251;
        CData/*1:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV;
        CData/*1:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE1;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIP;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIP;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__privValid;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_300;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEcall;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEbreak;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_443;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__iaddrInvalid;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__laddrInvalid;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__saddrInvalid;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_561;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_571;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isInstRet;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_608;
        CData/*3:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_628;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_631;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__regFile__DOT___T_33;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__isSameSign;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__lt;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__ltu;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__brCond__DOT___T_41;
        CData/*1:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_245;
        CData/*1:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_260;
        CData/*1:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_275;
        CData/*1:0*/ Tile__DOT__core__DOT__ctrl__DOT__ctrlSignals_0;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_301;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_318;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_354;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_371;
        CData/*2:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_391;
        CData/*2:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_406;
        CData/*2:0*/ Tile__DOT__core__DOT__ctrl__DOT__ctrlSignals_3;
        CData/*3:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_442;
        CData/*3:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_457;
        CData/*3:0*/ Tile__DOT__core__DOT__ctrl__DOT__ctrlSignals_4;
        CData/*2:0*/ Tile__DOT__core__DOT__ctrl__DOT__ctrlSignals_5;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_536;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_553;
        CData/*1:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_610;
    };
    struct {
        CData/*1:0*/ Tile__DOT__core__DOT__ctrl__DOT__ctrlSignals_7;
        CData/*2:0*/ Tile__DOT__core__DOT__ctrl__DOT__ctrlSignals_8;
        CData/*1:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_677;
        CData/*1:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_692;
        CData/*1:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_707;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_730;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_747;
        CData/*2:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_773;
        CData/*2:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_788;
        CData/*2:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_803;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_823;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___T_840;
        CData/*2:0*/ Tile__DOT__icache__DOT__state;
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_1_3___05FT_170_addr_pipe_0;
        CData/*3:0*/ Tile__DOT__icache__DOT__cpu_mask;
        CData/*0:0*/ Tile__DOT__icache__DOT__value;
        CData/*0:0*/ Tile__DOT__icache__DOT__value_1;
        CData/*0:0*/ Tile__DOT__icache__DOT__is_alloc_reg;
        CData/*0:0*/ Tile__DOT__icache__DOT__ren_reg;
        CData/*0:0*/ Tile__DOT__icache__DOT___T_111;
        CData/*0:0*/ Tile__DOT__icache__DOT___T_118;
        CData/*0:0*/ Tile__DOT__icache__DOT__read_wrap_out;
        CData/*0:0*/ Tile__DOT__icache__DOT__is_alloc;
        CData/*0:0*/ Tile__DOT__icache__DOT__hit;
        CData/*0:0*/ Tile__DOT__icache__DOT___T_130;
        CData/*0:0*/ Tile__DOT__icache__DOT__wen;
        CData/*0:0*/ Tile__DOT__icache__DOT__ren;
        CData/*0:0*/ Tile__DOT__icache__DOT___T_262;
        CData/*0:0*/ Tile__DOT__icache__DOT___GEN_58;
        CData/*0:0*/ Tile__DOT__icache__DOT__is_dirty;
        CData/*0:0*/ Tile__DOT__icache__DOT___T_482;
        CData/*0:0*/ Tile__DOT__icache__DOT___T_486;
        CData/*0:0*/ Tile__DOT__icache__DOT___T_494;
        CData/*0:0*/ Tile__DOT__icache__DOT___T_501;
        CData/*0:0*/ Tile__DOT__icache__DOT___T_503;
        CData/*0:0*/ Tile__DOT__icache__DOT___T_506;
        CData/*0:0*/ Tile__DOT__icache__DOT___T_509;
        CData/*0:0*/ Tile__DOT__icache__DOT___GEN_139;
        CData/*2:0*/ Tile__DOT__dcache__DOT__state;
        CData/*7:0*/ Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0;
        CData/*3:0*/ Tile__DOT__dcache__DOT__cpu_mask;
        CData/*0:0*/ Tile__DOT__dcache__DOT__value;
        CData/*0:0*/ Tile__DOT__dcache__DOT__value_1;
        CData/*0:0*/ Tile__DOT__dcache__DOT__is_alloc_reg;
        CData/*0:0*/ Tile__DOT__dcache__DOT__ren_reg;
        CData/*0:0*/ Tile__DOT__dcache__DOT___T_111;
        CData/*0:0*/ Tile__DOT__dcache__DOT___T_118;
        CData/*0:0*/ Tile__DOT__dcache__DOT__read_wrap_out;
        CData/*0:0*/ Tile__DOT__dcache__DOT___T_119;
        CData/*0:0*/ Tile__DOT__dcache__DOT___T_126;
        CData/*0:0*/ Tile__DOT__dcache__DOT__write_wrap_out;
        CData/*0:0*/ Tile__DOT__dcache__DOT__is_alloc;
        CData/*0:0*/ Tile__DOT__dcache__DOT__hit;
        CData/*0:0*/ Tile__DOT__dcache__DOT___T_130;
        CData/*0:0*/ Tile__DOT__dcache__DOT__wen;
        CData/*0:0*/ Tile__DOT__dcache__DOT__ren;
        CData/*0:0*/ Tile__DOT__dcache__DOT___T_262;
        CData/*0:0*/ Tile__DOT__dcache__DOT___GEN_58;
        CData/*0:0*/ Tile__DOT__dcache__DOT__is_dirty;
        CData/*0:0*/ Tile__DOT__dcache__DOT___T_482;
        CData/*0:0*/ Tile__DOT__dcache__DOT___T_486;
        CData/*0:0*/ Tile__DOT__dcache__DOT___T_492;
        CData/*0:0*/ Tile__DOT__dcache__DOT___T_493;
        CData/*0:0*/ Tile__DOT__dcache__DOT___T_494;
    };
    struct {
        CData/*0:0*/ Tile__DOT__dcache__DOT___T_496;
        CData/*0:0*/ Tile__DOT__dcache__DOT___T_501;
        CData/*0:0*/ Tile__DOT__dcache__DOT___T_503;
        CData/*0:0*/ Tile__DOT__dcache__DOT___T_505;
        CData/*0:0*/ Tile__DOT__dcache__DOT___T_506;
        CData/*0:0*/ Tile__DOT__dcache__DOT___T_509;
        CData/*0:0*/ Tile__DOT__dcache__DOT___GEN_138;
        CData/*0:0*/ Tile__DOT__dcache__DOT___GEN_139;
        CData/*0:0*/ Tile__DOT__dcache__DOT___GEN_140;
        CData/*0:0*/ Tile__DOT__dcache__DOT___GEN_141;
        CData/*2:0*/ Tile__DOT__arb__DOT__state;
        CData/*0:0*/ Tile__DOT__arb__DOT___T_221;
        CData/*0:0*/ Tile__DOT__arb__DOT___T_223;
        CData/*0:0*/ Tile__DOT__arb__DOT___T_227;
        CData/*0:0*/ Tile__DOT__arb__DOT___T_231;
        CData/*0:0*/ Tile__DOT__arb__DOT___T_259;
        CData/*0:0*/ Tile__DOT__arb__DOT___T_262;
        CData/*0:0*/ Tile__DOT__arb__DOT___T_271;
        CData/*0:0*/ Tile__DOT__arb__DOT___T_272;
        CData/*0:0*/ Tile__DOT__arb__DOT___T_275;
        CData/*0:0*/ Tile__DOT__arb__DOT___T_276;
        CData/*0:0*/ Tile__DOT__arb__DOT___T_278;
        CData/*0:0*/ Tile__DOT__arb__DOT___T_279;
        CData/*0:0*/ Tile__DOT__arb__DOT___T_282;
        CData/*0:0*/ Tile__DOT__arb__DOT___T_284;
        CData/*0:0*/ Tile__DOT__arb__DOT___T_285;
        CData/*0:0*/ Tile__DOT__arb__DOT___T_286;
        CData/*0:0*/ Tile__DOT__mmio__DOT__selector__DOT___T_87;
        CData/*0:0*/ Tile__DOT__mmio__DOT__selector__DOT___T_92;
        CData/*0:0*/ Tile__DOT__mmio__DOT__regMapper__DOT___T_84;
        CData/*0:0*/ Tile__DOT__mmio__DOT__regMapper__DOT___T_89;
        CData/*7:0*/ Tile__DOT__sender__DOT__cntReg;
        CData/*5:0*/ Tile__DOT__sender__DOT___GEN_3;
        CData/*0:0*/ Tile__DOT__sender__DOT___T_25;
        CData/*7:0*/ Tile__DOT__sender__DOT___T_28;
        CData/*0:0*/ Tile__DOT__sender__DOT__tx__DOT__tx__DOT__state;
        CData/*3:0*/ Tile__DOT__sender__DOT__tx__DOT__tx__DOT__value_1;
        CData/*0:0*/ Tile__DOT__sender__DOT__tx__DOT__tx__DOT___T_28;
        CData/*0:0*/ Tile__DOT__sender__DOT__tx__DOT__tx__DOT__baud_wrap_out;
        CData/*0:0*/ Tile__DOT__sender__DOT__tx__DOT__tx__DOT___T_36;
        CData/*3:0*/ Tile__DOT__sender__DOT__tx__DOT__tx__DOT___T_39;
        CData/*0:0*/ Tile__DOT__sender__DOT__tx__DOT__tx__DOT__bit_wrap_out;
        CData/*0:0*/ Tile__DOT__sender__DOT__tx__DOT__tx__DOT___T_43;
        CData/*0:0*/ Tile__DOT__sender__DOT__tx__DOT__tx__DOT___T_53;
        CData/*0:0*/ Tile__DOT__sender__DOT__tx__DOT__buf__024__DOT__state;
        CData/*7:0*/ Tile__DOT__sender__DOT__tx__DOT__buf__024__DOT__data;
        CData/*0:0*/ Tile__DOT__sender__DOT__tx__DOT__buf__024__DOT___T_30;
        CData/*0:0*/ Tile__DOT__sender__DOT__tx__DOT__buf__024__DOT___T_31;
        CData/*0:0*/ Tile__DOT__sender__DOT__tx__DOT__buf__024__DOT___T_33;
        CData/*0:0*/ Tile__DOT__uart__DOT__tx__DOT__tx__DOT__state;
        CData/*3:0*/ Tile__DOT__uart__DOT__tx__DOT__tx__DOT__value_1;
        CData/*0:0*/ Tile__DOT__uart__DOT__tx__DOT__tx__DOT___T_28;
        CData/*0:0*/ Tile__DOT__uart__DOT__tx__DOT__tx__DOT__baud_wrap_out;
        CData/*0:0*/ Tile__DOT__uart__DOT__tx__DOT__tx__DOT___T_36;
        CData/*3:0*/ Tile__DOT__uart__DOT__tx__DOT__tx__DOT___T_39;
        CData/*0:0*/ Tile__DOT__uart__DOT__tx__DOT__tx__DOT__bit_wrap_out;
        CData/*0:0*/ Tile__DOT__uart__DOT__tx__DOT__tx__DOT___T_43;
        CData/*0:0*/ Tile__DOT__uart__DOT__tx__DOT__tx__DOT___T_53;
        CData/*0:0*/ Tile__DOT__uart__DOT__tx__DOT__buf__024__DOT__state;
        CData/*7:0*/ Tile__DOT__uart__DOT__tx__DOT__buf__024__DOT__data;
        CData/*0:0*/ Tile__DOT__uart__DOT__tx__DOT__buf__024__DOT___T_30;
        CData/*0:0*/ Tile__DOT__uart__DOT__tx__DOT__buf__024__DOT___T_31;
        CData/*7:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT__shiftReg;
        CData/*1:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT__state;
    };
    struct {
        CData/*2:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT__value_2;
        CData/*0:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT___T_50;
        CData/*0:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT___T_20;
        CData/*0:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT__first_wrap_out;
        CData/*0:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT___T_27;
        CData/*0:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT___T_31;
        CData/*0:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT__baud_wrap_out;
        CData/*0:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT___T_36;
        CData/*0:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT___T_38;
        CData/*2:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT___T_45;
        CData/*0:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT__bit_wrap_out;
        CData/*7:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT___T_48;
        CData/*0:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT___T_51;
        CData/*0:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT___T_54;
        CData/*0:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT___T_55;
        CData/*0:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT___T_56;
        CData/*0:0*/ Tile__DOT__uart__DOT__rx__DOT__buf__024__DOT__state;
        CData/*7:0*/ Tile__DOT__uart__DOT__rx__DOT__buf__024__DOT__data;
        CData/*0:0*/ Tile__DOT__uart__DOT__rx__DOT__buf__024__DOT___T_30;
        CData/*0:0*/ Tile__DOT__uart__DOT__rx__DOT__buf__024__DOT___T_31;
        CData/*0:0*/ Tile__DOT__uart__DOT__rx__DOT__buf__024__DOT___T_33;
        CData/*3:0*/ Tile__DOT__ledController__DOT__ledState;
        CData/*2:0*/ Tile__DOT__uartController__DOT__state;
        CData/*0:0*/ Tile__DOT__uartController__DOT___T_43;
        CData/*0:0*/ Tile__DOT__uartController__DOT___T_51;
        CData/*0:0*/ Tile__DOT__uartController__DOT___T_65;
        CData/*0:0*/ Tile__DOT__uartController__DOT___T_72;
        CData/*0:0*/ Tile__DOT__uartController__DOT___T_79;
        CData/*0:0*/ Tile__DOT__uartController__DOT___T_87;
        CData/*0:0*/ Tile__DOT__uartController__DOT___GEN_34;
        CData/*0:0*/ Tile__DOT__uartController__DOT___GEN_36;
        SData/*11:0*/ Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___T_43;
        SData/*10:0*/ Tile__DOT__sender__DOT__tx__DOT__tx__DOT__shiftReg;
        SData/*10:0*/ Tile__DOT__sender__DOT__tx__DOT__tx__DOT__value;
        SData/*10:0*/ Tile__DOT__sender__DOT__tx__DOT__tx__DOT___T_31;
        SData/*10:0*/ Tile__DOT__sender__DOT__tx__DOT__tx__DOT___T_52;
        SData/*10:0*/ Tile__DOT__uart__DOT__tx__DOT__tx__DOT__shiftReg;
        SData/*10:0*/ Tile__DOT__uart__DOT__tx__DOT__tx__DOT__value;
        SData/*10:0*/ Tile__DOT__uart__DOT__tx__DOT__tx__DOT___T_31;
        SData/*10:0*/ Tile__DOT__uart__DOT__tx__DOT__tx__DOT___T_52;
        SData/*11:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT__value;
        SData/*10:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT__value_1;
        SData/*11:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT___T_23;
        SData/*10:0*/ Tile__DOT__uart__DOT__rx__DOT__rx__DOT___T_34;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__fe_inst;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__ew_inst;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__ew_alu;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr_in;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__rs1;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__rs2;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT___T_201;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT___T_202;
        WData/*286:0*/ Tile__DOT__core__DOT__dpath__DOT___T_220[9];
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__lshift;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time__024;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__timeh;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycleh;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instret;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instreth;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause;
    };
    struct {
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mfromhost;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_277;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_289;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_295;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_470;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_472;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_577;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_583;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_586;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_592;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_604;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___T_611;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__regFile__DOT___T_25;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_41;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_51;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_61;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_71;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT__shin;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_98;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_108;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_118;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_128;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_161;
        IData/*20:0*/ Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___T_45;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___T_53;
        WData/*255:0*/ Tile__DOT__icache__DOT__v[8];
        WData/*255:0*/ Tile__DOT__icache__DOT__d[8];
        IData/*19:0*/ Tile__DOT__icache__DOT__metaMem_tag_rmeta_data;
        IData/*31:0*/ Tile__DOT__icache__DOT__addr_reg;
        IData/*31:0*/ Tile__DOT__icache__DOT__cpu_data;
        WData/*127:0*/ Tile__DOT__icache__DOT__rdata_buf[4];
        WData/*255:0*/ Tile__DOT__icache__DOT___T_237[8];
        WData/*127:0*/ Tile__DOT__icache__DOT__rdata[4];
        WData/*127:0*/ Tile__DOT__icache__DOT__read[4];
        IData/*19:0*/ Tile__DOT__icache__DOT__wmask;
        WData/*127:0*/ Tile__DOT__icache__DOT__wdata[4];
        WData/*255:0*/ Tile__DOT__icache__DOT___T_279[8];
        WData/*255:0*/ Tile__DOT__icache__DOT___T_288[8];
        WData/*255:0*/ Tile__DOT__icache__DOT___T_290[8];
        WData/*255:0*/ Tile__DOT__dcache__DOT__v[8];
        WData/*255:0*/ Tile__DOT__dcache__DOT__d[8];
        IData/*19:0*/ Tile__DOT__dcache__DOT__metaMem_tag_rmeta_data;
        IData/*31:0*/ Tile__DOT__dcache__DOT__addr_reg;
        IData/*31:0*/ Tile__DOT__dcache__DOT__cpu_data;
        WData/*127:0*/ Tile__DOT__dcache__DOT__rdata_buf[4];
        WData/*255:0*/ Tile__DOT__dcache__DOT___T_237[8];
        WData/*127:0*/ Tile__DOT__dcache__DOT__rdata[4];
        WData/*127:0*/ Tile__DOT__dcache__DOT__read[4];
        IData/*19:0*/ Tile__DOT__dcache__DOT__wmask;
        WData/*127:0*/ Tile__DOT__dcache__DOT__wdata[4];
        WData/*255:0*/ Tile__DOT__dcache__DOT___T_279[8];
        WData/*255:0*/ Tile__DOT__dcache__DOT___T_288[8];
        WData/*255:0*/ Tile__DOT__dcache__DOT___T_290[8];
        IData/*31:0*/ Tile__DOT__mmio__DOT__selector__DOT__addr;
        IData/*31:0*/ Tile__DOT__mmio__DOT__selector__DOT___T_97;
        IData/*31:0*/ Tile__DOT__mmio__DOT__regMapper__DOT__addr;
    };
    struct {
        IData/*31:0*/ Tile__DOT__uartController__DOT__rdata;
        IData/*31:0*/ Tile__DOT__uartController__DOT__wdata;
        IData/*31:0*/ Tile__DOT__uartController__DOT___GEN_33;
        QData/*32:0*/ Tile__DOT__core__DOT__dpath__DOT__fe_pc;
        QData/*32:0*/ Tile__DOT__core__DOT__dpath__DOT__ew_pc;
        QData/*32:0*/ Tile__DOT__core__DOT__dpath__DOT__pc;
        QData/*32:0*/ Tile__DOT__core__DOT__dpath__DOT___T_170;
        QData/*32:0*/ Tile__DOT__core__DOT__dpath__DOT__npc;
        QData/*32:0*/ Tile__DOT__core__DOT__dpath__DOT___T_199;
        QData/*32:0*/ Tile__DOT__core__DOT__dpath__DOT__load;
        QData/*32:0*/ Tile__DOT__core__DOT__dpath__DOT___T_284;
        QData/*34:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_239;
        QData/*32:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_21;
        QData/*32:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___T_87;
        QData/*32:0*/ Tile__DOT__core__DOT__dpath__DOT__brCond__DOT___T_13;
        QData/*63:0*/ Tile__DOT__icache__DOT__refill_buf_0;
        QData/*63:0*/ Tile__DOT__icache__DOT__refill_buf_1;
        QData/*63:0*/ Tile__DOT__dcache__DOT__refill_buf_0;
        QData/*63:0*/ Tile__DOT__dcache__DOT__refill_buf_1;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[32];
        IData/*19:0*/ Tile__DOT__icache__DOT__metaMem_tag[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_0_0[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_0_1[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_0_2[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_0_3[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_1_0[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_1_1[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_1_2[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_1_3[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_2_0[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_2_1[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_2_2[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_2_3[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_3_0[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_3_1[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_3_2[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_3_3[256];
        IData/*19:0*/ Tile__DOT__dcache__DOT__metaMem_tag[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_0_0[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_0_1[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_0_2[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_0_3[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_1_0[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_1_1[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_1_2[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_1_3[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_2_0[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_2_1[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_2_2[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_2_3[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_3_0[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_3_1[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_3_2[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_3_3[256];
    };
    
    // LOCAL VARIABLES
    // Internals; generally not touched by application code
    CData/*0:0*/ __Vclklast__TOP__clock;
    IData/*31:0*/ __Vm_traceActivity;
    
    // INTERNAL VARIABLES
    // Internals; generally not touched by application code
    VTile__Syms* __VlSymsp;  // Symbol table
    
    // CONSTRUCTORS
  private:
    VL_UNCOPYABLE(VTile);  ///< Copying not allowed
  public:
    /// Construct the model; called by application code
    /// The special name  may be used to make a wrapper with a
    /// single model invisible with respect to DPI scope names.
    VTile(const char* name = "TOP");
    /// Destroy the model; called (often implicitly) by application code
    ~VTile();
    /// Trace signals in the model; called by application code
    void trace(VerilatedVcdC* tfp, int levels, int options = 0);
    
    // API METHODS
    /// Evaluate the model.  Application must call when inputs change.
    void eval();
    /// Simulation complete, run final blocks.  Application must call on completion.
    void final();
    
    // INTERNAL METHODS
  private:
    static void _eval_initial_loop(VTile__Syms* __restrict vlSymsp);
  public:
    void __Vconfigure(VTile__Syms* symsp, bool first);
  private:
    static QData _change_request(VTile__Syms* __restrict vlSymsp);
  public:
    static void _combo__TOP__4(VTile__Syms* __restrict vlSymsp);
  private:
    void _ctor_var_reset() VL_ATTR_COLD;
  public:
    static void _eval(VTile__Syms* __restrict vlSymsp);
  private:
#ifdef VL_DEBUG
    void _eval_debug_assertions();
#endif  // VL_DEBUG
  public:
    static void _eval_initial(VTile__Syms* __restrict vlSymsp) VL_ATTR_COLD;
    static void _eval_settle(VTile__Syms* __restrict vlSymsp) VL_ATTR_COLD;
    static void _initial__TOP__1(VTile__Syms* __restrict vlSymsp) VL_ATTR_COLD;
    static void _sequent__TOP__2(VTile__Syms* __restrict vlSymsp);
    static void _settle__TOP__3(VTile__Syms* __restrict vlSymsp) VL_ATTR_COLD;
    static void traceChgThis(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceChgThis__2(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceChgThis__3(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceChgThis__4(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceChgThis__5(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceFullThis(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) VL_ATTR_COLD;
    static void traceFullThis__1(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) VL_ATTR_COLD;
    static void traceInitThis(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) VL_ATTR_COLD;
    static void traceInitThis__1(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) VL_ATTR_COLD;
    static void traceInit(VerilatedVcd* vcdp, void* userthis, uint32_t code);
    static void traceFull(VerilatedVcd* vcdp, void* userthis, uint32_t code);
    static void traceChg(VerilatedVcd* vcdp, void* userthis, uint32_t code);
} VL_ATTR_ALIGNED(VL_CACHE_LINE_BYTES);

//----------


#endif  // guard
