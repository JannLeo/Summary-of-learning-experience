import java.net.*; 
public class Example11_4
{
	public static void main(String args[])
    {
		try
		{
			InetAddress address_1 = InetAddress.getByName("www.sina.com.cn");			
			System.out.println( address_1.toString() );
			System.out.println( address_1.getHostName() );
			System.out.println( address_1.getHostAddress() );
			
			//InetAddress address_2 = InetAddress.getByName("112.90.6.238");			
			//System.out.println(address_2.toString());
			//System.out.println(address_2.getHostName());
			//System.out.println(address_2.getHostAddress());
        }
        catch(UnknownHostException e)
        {
        	System.out.println("�޷��ҵ�www.sina.com.cn");
        }
    }
}
