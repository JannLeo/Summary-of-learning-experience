import javax.swing.*;

import java.awt.*;

public class Example10_6
{
    public static void main(String args[])
    {
        new WindowLayered(); 
    }
}

class WindowLayered extends JFrame
{
    WindowLayered()
    {
    	// ---
        setBounds(100,100,300,300);
        setVisible(true);
        
        // ---
        JButton b1 = new JButton("����DEFAULT_LAYER");
        JButton b2 = new JButton("����PALETTE_LAYER");
        JButton b3 = new JButton("����MODAL_LAYER");
        JButton b4 = new JButton("����POPUP_LAYER");
        JButton b5 = new JButton("����DRAG_LAYER");
        
        // ---
        b5.setBounds(50,50,200,100);
        b4.setBounds(40,40,200,100);
        b3.setBounds(30,30,200,100);
        b2.setBounds(20,20,200,100);
        b1.setBounds(10,10,200,100);
                
        // ---
        JLayeredPane pane = new JLayeredPane();        
        pane.setLayout(null);
        
        // ---
        pane.add(b5,JLayeredPane.DRAG_LAYER);
        pane.add(b4,JLayeredPane.POPUP_LAYER);
        pane.add(b3,JLayeredPane.MODAL_LAYER);
        pane.add(b2,JLayeredPane.PALETTE_LAYER);
        pane.add(b1,JLayeredPane.DEFAULT_LAYER);
        
        // ---        
        add(pane, BorderLayout.CENTER);
                
        // ---
        validate();
        
        // ---
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
