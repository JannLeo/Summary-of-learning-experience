import java.awt.event.*; 
import java.awt.*;
import javax.swing.*;

public class Example10_32
{
    public static void main(String args[])
    {
        new ColorWin("����ɫ�Ի���Ĵ���");
    }
}


class ColorWin extends JFrame implements ActionListener
{
	JButton buttonOpen,showColor;
    ColorWin(String s)
    {
    	// ---
    	setTitle(s);
        
    	// ---
    	buttonOpen = new JButton("����ɫ�Ի���");
        buttonOpen.addActionListener(this);
        add(buttonOpen,BorderLayout.NORTH);
        
        // ---
        showColor = new JButton();  
        add(showColor,BorderLayout.CENTER);
        
        // ---
        setBounds(60,60,300,300);
        setVisible(true);
        
        // ---
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    
    public void actionPerformed(ActionEvent e)
    {
        Color newColor = JColorChooser.showDialog(this, "��ɫ��", showColor.getBackground());
        if(newColor!=null)
        {
        	showColor.setBackground(newColor);
        }
    }
}
