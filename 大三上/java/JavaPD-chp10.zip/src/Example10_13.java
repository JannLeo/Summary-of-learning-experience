import javax.swing.*; 
import java.awt.*; 
import java.awt.event.*;
public class Example10_13
{
    public static void main(String args[])
    {
        new CheckBoxWindow();
    }
}

class CheckBoxWindow extends JFrame implements ItemListener
{
    JCheckBox box;
    JLabel imageLabel;
    CheckBoxWindow()
    {
        box = new JCheckBox("�Ƿ���ʾͼ��");
        imageLabel = new JLabel(new ImageIcon("e.jpg"));
        imageLabel.setVisible(false);  
        add(box, BorderLayout.NORTH);
        add(imageLabel, BorderLayout.CENTER);
        validate();
        box.addItemListener(this);
        setBounds(120,120,260,270);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
    }
    
    public void itemStateChanged(ItemEvent e)
    {
    	JCheckBox box = (JCheckBox)e.getItemSelectable();
        if(box.isSelected())
        {
           imageLabel.setVisible(true);
        }
        else
        {
           imageLabel.setVisible(false);
        }
    }
}
