import javax.swing.*; 
import javax.swing.tree.*;	
import java.awt.*;
import javax.swing.event.*;

public class Example10_16
{
    public static void main(String args[])
    {
        new TreeWin(); 
    } 
}

class Student
{
    String name;
    double score;
    Student(String name,double score)
    {
    	this.name=name;
    	this.score=score;
    }
    
    public String toString()
    {
    	return name;
    }
}

class TreeWin extends JFrame implements TreeSelectionListener
{
	JTree tree;
    JTextArea showText;
    
    // ---
    TreeWin()
    {
		DefaultMutableTreeNode root = new DefaultMutableTreeNode("��ѧ"); // ���ڵ�
		DefaultMutableTreeNode node = new DefaultMutableTreeNode("ѧ��"); // �ڵ�
		DefaultMutableTreeNode nodeson1 = new DefaultMutableTreeNode(new Student("����", 99)); // �ڵ�
		DefaultMutableTreeNode nodeson2 = new DefaultMutableTreeNode(new Student("����", 88)); // �ڵ�
		DefaultMutableTreeNode nodeson3 = new DefaultMutableTreeNode(new Student("����", 77)); // �ڵ�
		root.add(node); // ȷ���ڵ�֮��Ĺ�ϵ
		node.add(nodeson1); // ȷ���ڵ�֮��Ĺ�ϵ
		node.add(nodeson2);
		node.add(nodeson3);
		
		tree = new JTree(root); // ��root�����������
		tree.addTreeSelectionListener(this); // ����������ϵ��¼�
		showText = new JTextArea();
		setLayout(new GridLayout(1, 2));
		add(new JScrollPane(tree));
		add(new JScrollPane(showText));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setBounds(80, 80, 300, 300);
		validate();
    }
    
    // ---
    public void valueChanged(TreeSelectionEvent e)
    {
    	DefaultMutableTreeNode node = (DefaultMutableTreeNode)tree.getLastSelectedPathComponent();
    	if(node.isLeaf())
    	{
    		Student s = (Student)node.getUserObject(); //�õ��ڵ��д�ŵĶ���
    		showText.append(s.name+","+s.score+"\n");  
    	}
    	else
    	{
    		showText.setText(null);
    	}
    }
}
