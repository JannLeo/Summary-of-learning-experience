import javax.swing.*; 
import java.awt.*;
import javax.swing.border.*;

public class Example10_5
{
    public static void main(String args[])
    {
        new WindowBox(); 
    }
}


class WindowBox extends JFrame
{
    Box baseBox, boxV1, boxV2; 
    WindowBox()
    {
    	// ---
        boxV1 = Box.createVerticalBox();
        boxV1.add(new JLabel("������������"));
        boxV1.add(Box.createVerticalStrut(8));
        boxV1.add(new JLabel("����email"));
        boxV1.add(Box.createVerticalStrut(8));
        boxV1.add(new JLabel("��������ְҵ"));
        
        // ---
        boxV2 = Box.createVerticalBox();
        boxV2.add(new JTextField(16));
        boxV2.add(Box.createVerticalStrut(8));
        boxV2.add(new JTextField(16));
        boxV2.add(Box.createVerticalStrut(8));
        boxV2.add(new JTextField(16));
        
        // ---
        baseBox = Box.createHorizontalBox();
        baseBox.add(boxV1);
        baseBox.add(Box.createHorizontalStrut(10));
        baseBox.add(boxV2);
        
        // ---
        FlowLayout flow = new FlowLayout();
        flow.setAlignment(FlowLayout.LEFT);
        setLayout(flow);
        
        // ---
        this.add(baseBox);
        
        // ---
        validate();
        
        // ---
        setBounds(120,125,200,200);        
        setVisible(true);
        
        // ---
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
