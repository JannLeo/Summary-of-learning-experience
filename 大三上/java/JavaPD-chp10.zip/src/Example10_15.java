import javax.swing.*;
import java.awt.*;
import java.awt.event.*; 

public class Example10_15
{
    public static void main(String args[])
    {
    	Win10_15 win = new Win10_15();  
    }
}

class Win10_15 extends JFrame implements ActionListener
{
    JTable table;
    Object a[][];
    Object name[]={"��Ʒ����","����","������","���۶�"};
    JButton computerRows,computerColums;
    JTextField inputRowsNumber;
    int initRows = 1;
    JPanel pSouth, pNorth;
    int count=0, rowsNumber=0;
    Win10_15()
    {
    	computerRows = new JButton("ÿ����Ʒ���۶�");
        computerColums = new JButton("�����۶�");
        inputRowsNumber = new JTextField(10);
        computerRows.addActionListener(this);
        computerColums.addActionListener(this);
        inputRowsNumber.addActionListener(this);
        pSouth = new JPanel();
        pNorth = new JPanel();
        pNorth.add(new JLabel("�����������,�س�ȷ��"));
        pNorth.add(inputRowsNumber);
        pSouth.add(computerRows);
        pSouth.add(computerColums);
        add(pSouth,BorderLayout.SOUTH);
        add(pNorth,BorderLayout.NORTH);
        add(new JScrollPane(table),BorderLayout.CENTER);
        
        setBounds(100,100,370,250);
        setVisible(true);
        validate();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    
    public void actionPerformed(ActionEvent e)
    {
    	if(e.getSource()==inputRowsNumber)
    	{
    		count = 0;
			initRows = Integer.parseInt(inputRowsNumber.getText());
			a = new Object[initRows][4];
			for (int i=0; i<initRows; i++) 
			{
				for(int j=0; j<4; j++)
				{
					a[i][j] = "0";
				}
			}
			
			table = new JTable(a, name);
			table.setRowHeight(20);
			getContentPane().removeAll();
			add(new JScrollPane(table), BorderLayout.CENTER);
			add(pSouth, BorderLayout.SOUTH);
			add(pNorth, BorderLayout.NORTH);
			validate();
        }
        else
        {
        	if(e.getSource()==computerRows)
        	{
	           int rows = table.getRowCount(); //��ȡ���б��������
	           
	           for(int i=0; i<rows; i++)
	           {
	              double sum = 1;
	              boolean boo = true;
	              for(int j=1;j<=2;j++)
	              {
	                 try
	                 {
	                	 sum=sum*Double.parseDouble(a[i][j].toString());
	                 }
	                 catch(Exception ee)
	                 {
	                	 boo=false;
	                	 table.repaint();         //���������ʾ
	                 }
	                 
	                 if(boo==true)
	                 {
	                	 a[i][3]=""+sum;            //�޸������е�����
	                	 table.repaint();
	                 }
	              }
	           }
        	}
        	else 
        	{
        		if(e.getSource()==computerColums)
        		{
        			if(count==0)
        			{
        				rowsNumber = table.getRowCount(); //��ȡ�����Ŀǰ������
        				count++;
        			}
	        		else
	        		{
	        			rowsNumber=table.getRowCount(); // ��ȡ�����Ŀǰ������
	        			rowsNumber=rowsNumber-1; // ��Ҫ���һ��
	        		}
	        		double totalSum=0;
	        		for(int j=0; j<rowsNumber; j++)
	        		{
	        			totalSum=totalSum+Double.parseDouble(a[j][3].toString());
	        		}
	        		Object b[][] = new Object[rowsNumber+1][4]; // ������a��һ�е�����
	        		for(int i=0;i<rowsNumber;i++)
	        		{ 
	        			// ������a�����ݸ��Ƶ�����b��
	        			for(int j=0;j<4;j++)
	        			{
	        				b[i][j]=a[i][j];
	        			}
	        		}
        		
		           b[rowsNumber][0] = "һ����"+rowsNumber+"����Ʒ";
		           b[rowsNumber][3] = "�����۶"+totalSum;
		           a = b; // ���³�ʼ��a
		           table = new JTable(a,name);
		           getContentPane().removeAll();
		           add(new JScrollPane(table),BorderLayout.CENTER);
		           add(pSouth,BorderLayout.SOUTH);
		           add(pNorth,BorderLayout.NORTH);
		           validate();
        		}
        	}
        }
    }
}
