import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Example10_26
{
	public static void main(String args[])
	{
		new ThreadWin();
	}
}

// ---
class ThreadWin extends JFrame implements Runnable,ActionListener
{
	Thread moveOrStop;
	JButton start, hang, resume, die;
	JLabel moveLabel;
	boolean move=false, dead=false;
	ThreadWin()
	{
		// ---
		moveOrStop = new Thread(this);

		// ---
		start = new JButton("�߳̿�ʼ");
		hang = new JButton("�̹߳���");
		resume = new JButton("�ָ̻߳�");
		die = new JButton("�߳���ֹ");

		start.addActionListener(this);
		hang.addActionListener(this);
		resume.addActionListener(this);
		die.addActionListener(this);

		// ---
		moveLabel=new JLabel("�̸߳����˶���");
		moveLabel.setBackground(Color.red);
		
		// ---
		add(start);
		add(hang);
		add(resume);
		add(die);
		add(moveLabel);
		

		// ---
		setLayout(new FlowLayout());
				
		// ---
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	// ---
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==start)
		{
			try 
			{
				move=true;
				moveOrStop.start();      //�����߳�
			}
			catch(Exception event){}
		}
		else if(e.getSource()==hang)
		{
			move=false;
		}
		else if(e.getSource()==resume)
		{
			move=true;
			resumeThread();               //�ָ��߳�
		}
		else if(e.getSource()==die)
		{
			dead=true;
		}
	}
	
	// ---
	public void run()
	{
		while(true)
		{
			while(!move)
			{
				try{
					hangThread();          //�����߳�
				}
				catch(InterruptedException e1){}
			}
			
			int x = moveLabel.getBounds().x;
			int y = moveLabel.getBounds().y;
			y=y+2;
			if(y>=200)
			{
				y=10;
			}
			moveLabel.setLocation(x,y);
			
			try{
				moveOrStop.sleep(200); 
			}
			catch(InterruptedException e2){}
			if(dead==true)
			{
				return;                     //��ֹ�߳�
			}
		}
	}
	
	public synchronized void hangThread() throws InterruptedException
	{
		wait();
	}
	
	public synchronized void resumeThread()
	{
		notifyAll();
	}
	
} 
