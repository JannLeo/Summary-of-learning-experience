xxl.cpp是算法源代码

lab3.py是图形演示源码

demo是图形演示的动图