#ifndef SUB_H
#define SUB_H

double sub(double a, double b);

#endif
