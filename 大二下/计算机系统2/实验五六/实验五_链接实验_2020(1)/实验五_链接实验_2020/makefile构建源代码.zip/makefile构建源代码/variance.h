#ifndef VARINCE_H
#define VARINCE_H

#include "add.h"
#include "sub.h"
#include <math.h>
int variance_ceil(double a, double b);
int variance_floor(double a, double b);

#endif
