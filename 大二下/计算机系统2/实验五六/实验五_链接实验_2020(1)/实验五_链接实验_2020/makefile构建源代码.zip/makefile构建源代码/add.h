#ifndef ADD_H
#define ADD_H

double add(double a, double b);

#endif
