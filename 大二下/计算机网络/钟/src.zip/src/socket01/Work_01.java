package socket01;

import java.net.*;

public class Work_01 
{
	public static void main(String[] args) 
	{
		try 
		{
			InetAddress ina=InetAddress.getLocalHost();
			String hostName=ina.getHostName();
			String hostAddress=ina.getHostAddress();
			System.out.println(hostName);
			System.out.println(hostAddress);
			System.out.println(ina.toString());
		}
		catch (UnknownHostException e)
		{
			e.printStackTrace();
		}

	}
}
