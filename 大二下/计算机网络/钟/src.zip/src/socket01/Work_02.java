package socket01;

import java.net.*;

public class Work_02
{
	public static void main(String[] args)
	{
		try 
		{
			InetAddress []ina=InetAddress.getAllByName("www.csdn.net");
			
			//System.out.println(ina.isMulticastAddress());
			for(InetAddress tina:ina)
			System.out.println(tina.getHostAddress());
			
			
		} 
		catch (UnknownHostException e) 
		{
			e.printStackTrace();
		}
		

	}
}
