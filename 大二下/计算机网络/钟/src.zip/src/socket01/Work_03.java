package socket01;

import java.net.*;
import java.io.*;

public class Work_03 
{
	public static void main(String args[ ])throws Exception
    {
		URL url=new URL("https://www.szu.edu.cn");
		InputStream in=url.openStream();
		FileOutputStream fout=new FileOutputStream(new File("szu.html"));
		int a=0;
		while(a>-1)
		{
			a=in.read();
			fout.write(a);
		}
		URLConnection urlCon=url.openConnection();
		System.out.println("�ļ���С��"+urlCon.getContentLength());
	}

}
