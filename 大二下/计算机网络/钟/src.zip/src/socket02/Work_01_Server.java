package socket02;

import java.io.*;
import java.net.*;
import java.util.*;

class ServerRun implements Runnable{
	private Socket sevsk;
	public ServerRun(Socket s1)
	{
		sevsk=s1;
		new Thread(this).start();
	}
	public void run() {

		try 
		{
			BufferedReader br=new BufferedReader(new InputStreamReader(sevsk.getInputStream()));
			BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(sevsk.getOutputStream()));
			
			while(true)
			{
				String str=br.readLine();

				if(str.equals("Exit"))
				{
					bw.write("bye\n");
					System.out.println("����ͻ��˷���\"bye\"\n");
					bw.flush();
					break;
				}
				else if(str.equals("Time"))
				{
					String s="��������ǰʱ�䣺"+Calendar.getInstance().getTime().toString()+"\n";
					System.out.println("����ͻ��˷���"+s);
					bw.write(s);
					bw.flush();
				}
				
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}
public class Work_01_Server
{

	public static void main(String[] args) {
		
		try 
		{
			ServerSocket ss=new ServerSocket(11111);
			System.out.println("�������������");
			while(true)
			{
				Socket s=ss.accept();
				System.out.println("�����ͻ�����");
				new ServerRun(s);
			}
			
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
	}

}

