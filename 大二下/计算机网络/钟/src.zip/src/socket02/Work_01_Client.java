package socket02;

import java.io.*;
import java.net.*;
import java.util.*;

class ClientRun implements Runnable
{
	private Socket clisk;
	public ClientRun()
	{
		try 
		{
			clisk=new Socket(InetAddress.getLocalHost(),11111);
			new Thread(this).start();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	public void run()
	{
		
		try 
		{
			BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(clisk.getOutputStream()));
			BufferedReader br=new BufferedReader(new InputStreamReader(clisk.getInputStream()));
			Scanner sc=new Scanner(System.in);
			String order=null;
			
			while(order!="Exit")
			{
				order=sc.nextLine();
				bw.write(order+"\n");
				bw.flush();
				System.out.println(br.readLine());
			}
			
			clisk.close();
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
	}
}

public class Work_01_Client 
{
	public static void main(String[] args) 
	{
		new ClientRun();
	}
}