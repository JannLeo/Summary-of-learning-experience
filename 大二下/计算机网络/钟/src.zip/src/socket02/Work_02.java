package socket02;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import java.text.*;

class UDPGUI
{
	
	JFrame jf=new JFrame();
	JPanel jp2=new JPanel();
	TextField ip=new TextField(10);
	TextField in=new TextField(20);
	TextArea  ta=new TextArea(14,18);
	Button bu=new Button("����");
	Button clear=new Button("����");
	String name;
	public UDPGUI(String name) {
		
		this.name=name;
		
		jf.setTitle("UDP�������");
		jf.setBounds(200, 200, 480, 300);		
		jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		jf.setVisible(true);
		jf.setResizable(false);	
		
		ta.setBackground(Color.white);
		ta.setEditable(false);
		
		ip.setEditable(false);	
		ip.setBackground(Color.white);
		
		try 
		{
			ip.setText(InetAddress.getLocalHost().getHostAddress().toString());
		}
		catch (UnknownHostException e) 
		{
			e.printStackTrace();
		}

		jp2.add(ip,BorderLayout.WEST);
		jp2.add(in,BorderLayout.CENTER);
		jp2.add(bu,BorderLayout.EAST);
		jp2.add(clear,BorderLayout.EAST);
		
		//����λ����Ϣ���ں�ͬһ����λ��
		jf.setLayout(new BorderLayout());
		jf.add(ta,BorderLayout.NORTH);
		jf.add(jp2,BorderLayout.SOUTH);
		
	}
	
}

class Send{
	int post;
	DatagramSocket ds;
	
	public Send(int post) {
		try {
			
			this.post=post;
			ds=new DatagramSocket();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	//������str��������ݰ����ͳ�ȥ
	public void send(String str) {
		
		try {
			byte []b=str.getBytes();
			DatagramPacket dp;
			dp = new DatagramPacket(b, b.length,InetAddress.getLocalHost(),post);
			ds.send(dp);
			
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		
		
	}
}

class Receiver{
	DatagramSocket ds;
	public Receiver(int post) {
		
		try {
			ds=new DatagramSocket(post);
		} catch (SocketException e) {
			e.printStackTrace();
		} 
		
	}

	public String getStr() {
		
		byte []b=new byte[1024];
		DatagramPacket dp=new DatagramPacket(b,b.length);
		
		try {
			ds.receive(dp);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return new String(b);
	}
}

class UDPexchange implements Runnable,ActionListener{
	
	
	Thread th;
	Send s;
	Receiver r;
	String name;		
	UDPGUI win;			
	
	//begΪudp���Ͷ˿ڣ�endΪ���ܶ˿ڣ�nameΪ�������
	public UDPexchange(int beg,int end,String name) {
		s=new Send(beg);
		r=new Receiver(end);
		win=new UDPGUI(name);
		this.name=name;
		th=new Thread(this);
		th.start();
	}
	
	public void run() {

		win.bu.addActionListener(this);
		win.clear.addActionListener(this);
		
		while(true)
		{
			
			try {
				win.ta.append(msg(true)+r.getStr());
			} catch (UnknownHostException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			win.ta.append("\n");
			
		}
		
	}

	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==win.clear)
			win.ta.setText("");
		else if(e.getSource()==win.bu)
		{
			String str=win.in.getText();
			try {
				win.ta.append(msg(false)+str);
			} catch (UnknownHostException e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
			win.ta.append("\n");
			win.in.setText("");
			s.send(str);
			
		}
	}
	
	public String msg(boolean flag) throws UnknownHostException
	{
		Calendar c=Calendar.getInstance();
		Date d=c.getTime();
		if(flag)
			return name+"\n"+"   ";
		else
			return InetAddress.getLocalHost().getHostAddress().toString()+"Myself:\n"+"   ";
	}
}

public class Work_02 
{
	public static void main(String[] args) 
	{
		new UDPexchange(10001,10086,"Jack");
		new UDPexchange(10086,10001,"Tom");
	}
}
